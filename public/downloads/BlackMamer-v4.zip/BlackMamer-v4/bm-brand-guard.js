/* BLACKMAMERSTUDIO signed integrity guard — official client-side checks. */
(()=>{
 'use strict';
 const KEY='MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAExl2jUBD0NHbWZ/POLQWsdlc5KT18uxgy3EbsAZjckH0c4o3fK6LBzE133Lt41gapGG8RB1A0g2yooVVESP7+pQ==';
 const ERROR='BLACKMAMERSTUDIO: integritas UI / branding tidak valid. Gunakan paket resmi tanpa mengganti nama BLACKMAMER atau file extension.';
 let lastAt=0,good=false,inflight=null,locked=false;
 const b64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
 const hash=b=>Array.from(new Uint8Array(b),v=>v.toString(16).padStart(2,'0')).join('');
 const stable=v=>Array.isArray(v)?'['+v.map(stable).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+stable(v[k])).join(',')+'}':JSON.stringify(v);
 async function lock(e){
   if(locked)return;locked=true;console.error('[BLACKMAMERSTUDIO] Build locked: tamper detected.',e?.message);
   try{await chrome.storage.local.set({bmBrandLock:{locked:true,reason:'Asset integrity check failed',at:Date.now()}});}catch{}
   try{const engine=globalThis.BMEngine;if(engine?.enabled)await engine.enabled(false);}catch{}
   try{const scripts=await chrome.userScripts.getScripts();if(scripts.length)await chrome.userScripts.unregister({ids:scripts.map(s=>s.id)});}catch{}
 }
 async function run(){
   const response=await fetch(chrome.runtime.getURL('bm-brand-seal.json'),{cache:'no-store'});
   if(!response.ok)throw Error('Official seal missing');
   const {payload:p,signature}=await response.json();
   if(!p||p.brand!=='BLACKMAMERSTUDIO'||p.product!=='BlackMamer'||p.policy!=='official-asset-integrity-v1'||!p.files||typeof signature!=='string')throw Error('Invalid signed metadata');
   const key=await crypto.subtle.importKey('spki',b64(KEY),{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
   if(!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},key,b64(signature),new TextEncoder().encode(stable(p))))throw Error('Invalid official signature');
   const manifest=chrome.runtime.getManifest();
   if(manifest.name!=='BlackMamer'||manifest.short_name!=='BlackMamer'||manifest.version!==p.version||manifest.version_name!==p.versionName||!manifest.action?.default_title?.includes('BLACKMAMERSTUDIO'))throw Error('BLACKMAMERSTUDIO name changed');
   for(const [filename,expected] of Object.entries(p.files)){
     if(!/^[a-zA-Z0-9_./-]+$/.test(filename)||filename.includes('..')||!/[a-f0-9]{64}/.test(expected))throw Error('Invalid asset metadata');
     const file=await fetch(chrome.runtime.getURL(filename),{cache:'no-store'});
     if(!file.ok)throw Error('Missing asset '+filename);
     if(hash(await crypto.subtle.digest('SHA-256',await file.arrayBuffer()))!==expected)throw Error('Modified asset '+filename);
   }
   if(locked)throw Error('Install clean official extension and reload');
   try{await chrome.storage.local.remove('bmBrandLock');}catch{}
   return true;
 }
 const verify=(force=false)=>{
   if(locked)return Promise.reject(Error(ERROR));
   if(!force&&good&&Date.now()-lastAt<15000)return Promise.resolve(true);
   if(inflight)return inflight;
   inflight=run().then(x=>{good=true;lastAt=Date.now();return x;}).catch(async e=>{await lock(e);throw Error(ERROR);}).finally(()=>{inflight=null;});
   return inflight;
 };
 globalThis.BMBrandGuard=Object.freeze({verify,isLocked:()=>locked});
})();
