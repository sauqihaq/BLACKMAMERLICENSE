# BlackMamer Script Studio v4

UI abu gelap, aksen merah lembut, logo BlackMamer, dan donasi Sociabuzz.

## Pasang paket pengembangan
1. Ekstrak BlackMamer-v4.zip ke folder tetap.
2. Buka chrome://extensions, aktifkan Developer mode, pilih Load unpacked, lalu pilih folder yang memuat manifest.json.
3. Pada Details ekstensi, aktifkan Allow user scripts.
4. Buka dashboard lewat ikon BlackMamer. Script baru/import .user.js tetap bisa dibuat dan diedit.
5. Jangan hapus ekstensi lama sebelum mencadangkan script pribadi. Instalasi sebagai ekstensi baru tidak memindahkan storage atau lisensi browser lama otomatis.

## Link pembelian
Website memerlukan perubahan backend V14 yang disertakan pada repository/PR. Setelah perubahan website dideploy:
- Admin login → Script & Install Links → pilih produk → upload .user.js.
- Buat/pilih lisensi pelanggan setelah pembayaran, kemudian tentukan tanggal dan jam kedaluwarsa link sendiri.
- Kirim link yang dihasilkan. Pelanggan membuka link, klik Install userscript, dan mengonfirmasi di ekstensi.
- Satu lisensi terikat ke satu identitas browser. Retry browser yang sama diperbolehkan. Masa pakai setelah klaim mengikuti lisensi, bukan tanggal link.
- Cabut link atau lisensi untuk menolak eksekusi berikutnya. Script yang sudah berjalan pada halaman terbuka tidak dibatalkan seketika; muat ulang halaman menghentikan eksekusi baru. Status ekstensi diverifikasi berkala setiap 5 menit.
- Produk memerlukan koneksi server saat mulai berjalan; saat server tidak tersedia, kode produk tidak dijalankan.

Produk berlisensi tidak memiliki tombol editor/export dan dikecualikan dari backup/sinkronisasi bawaan. Kode yang berjalan di perangkat pembeli tetap dapat diekstrak oleh pengguna teknis; ini bukan jaminan kerahasiaan 100%. Simpan logika yang benar-benar rahasia di server. Script pribadi tetap punya editor/import/export; backup JSON dapat dipulihkan lewat Pengaturan → Advanced tools → Utilities.

## Instalasi dari website
Tombol website mendeteksi ekstensi yang sudah dipasang. Instalasi standar tanpa Load unpacked memerlukan listing Chrome Web Store yang telah disetujui, lalu konfigurasi CHROME_WEB_STORE_URL di Vercel. Paket ini belum merupakan listing Web Store dan website tidak bisa memasang ekstensi secara diam-diam.

Source upload baru disimpan terenkripsi di database. Simpan SCRIPT_ENCRYPTION_KEY (atau ADMIN_SESSION_SECRET yang dipakai sebagai fallback) dengan aman dan jangan menggantinya tanpa migrasi. Template lama yang sudah publik tidak menjadi rahasia secara retroaktif.

Donasi: https://sociabuzz.com/sauqihaq69/tribe
Website: https://blackmamerlicense.vercel.app
Asal engine dan pemberitahuan lisensi ada di NOTICE-BLACKMAMER.txt.


## Official BLACKMAMERSTUDIO v4.4
This official extension uses a signed asset manifest and static MV3-compatible JavaScript obfuscation. It checks branding, engine/UI source and 32 assets at startup and regularly; invalid assets disable the extension. Existing website-bound product licenses are preserved; no second key entry is needed. Signing private key is not included in the distribution. Integrity checks can be bypassed by an adversary controlling local files, so license enforcement must remain server-side.
