
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_edf1f537c7=(()=>{const d=["mt9VO5j/P1aI5objv5+pyypPfRHilxF8Xn4RYqTNdRS/zw==","bMzHRt0aoJ7xcyR3PmmjxEATT9Y=","e8MwGqPd+Dl7+c1Qj+SY4TiR4sUvTcITB5E=","huYvmM3OxUTeHEaY2nFcdbpnbcrZEXLUZDY=","E3MkbYLAVR+Z2nY89/oOXa/rvuzEkobAE0o=","BlTe4CXl+J1Uyb1B4R+Cld5+VngDZIDP","KpyQdTNxPmsOxhQdk9jAMkD0o1/X6crq","aTv2/r1RMOdr4LSeFsQVThsSo5Zwe7p/UGGDzDwL","a0UwG6SZVHJcdE1o7MsmEuvVRTHH8XJY2+zf6Q==","hBmN3NE+PvjgUz3lyO4CkL7GEUwJFHyQfHm7feh/RdI=","W5uMz0JDpB1om8dwQ3pKZj7JfRDw06k3LvPUWtPyyfcJi0ffE1OSDUuL7mBXall2ONl2APzDoydL49RKz8LEx3K7te9tY4Q9Srs=","X2ywxxweodnhPdT1nVwZ6Fbt35UpwTVJLxedjQpmjGB9fKjXFQ70ybgtxeWQTBP4V/3IhT7RLVkjB6O9GFbRUDhM+udbPun54B2c1cB8X8hzzaW1X+FQaUE3+61qRu9ADFzb93Uu1unQDanFu2w92Ardr6VZ8Vh5USfP3RY2nTAsLPWHUV7qmeZ90bXVHEyoGK2U1W6BPAlyV9bNGSbAICA8p5c=","3uHu4oWc1spVQAgQh5RlfWh5OmPgziUVh9AiKvPsT0fr8bvyhYzB2qZQ9wB7hJ1tmGmNc2Xe7AU2wNcaFtz+dwzBHsJ+vC/qs2CpMH20gV2VWZdDPO6sNTPwygoDzK9nFdFb0mOsOvqXcNwgTaS2TblJplMA/tQlHODyejm80BduoQ+iVtwXipYAiVBf1LY9rzm4IxSOyFUOkKNqM6yHBzqxOrJMzFOa4xCwQDfE1S3GKd8zdp7yRQ==","G3SDds5qS8WqHOXXtzMX98NeAu7u6w==","Nf7tUQDkB+GnkXHFsE1eE4iRO3rKfI1g5tOuCifNcSmz6R9AA/QZ8bCBZNU=","XhzimCFx/HUTZ9jKdBHF1N02sPD+W33tKvaniEXeQVQ="],k=[223,58,253,85,226,230,153,204,71,24,157,119,114,111,195,27],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
(()=>{let enabled=true;const $=id=>document.getElementById(id),api=async(action,data={})=>{const r=await chrome.runtime.sendMessage({bm:{action,...data}});if(!r?.ok)throw Error(r?.error||(__BMS_edf1f537c7(0)));return r.result;};async function load(){try{const s=await api('state');enabled=s.enabled;$((__BMS_edf1f537c7(1))).textContent=s.scripts.length+' script terpasang · '+s.scripts.filter(s=>s.enabled).length+' aktif'+(s.scriptsAllowed?'':'. Aktifkan Allow user scripts di detail ekstensi.');$((__BMS_edf1f537c7(2))).textContent=enabled?(__BMS_edf1f537c7(3)):(__BMS_edf1f537c7(4));$((__BMS_edf1f537c7(5))).setAttribute((__BMS_edf1f537c7(6)),String(enabled));}catch(e){$('popup-info').textContent=e.message;if(/BLACKMAMERSTUDIO|integritas|brand/i.test(e.message)){$('popup-toggle').disabled=true;}}}$((__BMS_edf1f537c7(5))).onclick=async()=>{try{await api('enabled',{enabled:!enabled});await load();}catch(e){$((__BMS_edf1f537c7(1))).textContent=e.message;}};$((__BMS_edf1f537c7(7))).onclick=()=>chrome.tabs.create({url:chrome.runtime.getURL((__BMS_edf1f537c7(8)))});load();})();

/* BLACKMAMERSTUDIO official signed UI — engine enforces the lock. */
(()=>{
 'use strict';let locked=false;
 function showLocked(message){
   if(locked)return;locked=true;
   const overlay=document.createElement('div');overlay.className='bm-integrity-overlay';
   const box=document.createElement('div');box.className=(__BMS_edf1f537c7(9));
   const title=document.createElement('strong');title.textContent=(__BMS_edf1f537c7(10));
   const body=document.createElement('p');body.textContent=message||(__BMS_edf1f537c7(11));
   const note=document.createElement('small');note.textContent=(__BMS_edf1f537c7(12));
   box.append(title,body,note);overlay.append(box);document.body.append(overlay);
 }
 async function check(){
   try{const response=await chrome.runtime.sendMessage({bm:{action:(__BMS_edf1f537c7(13))}});
     if(!response?.ok||response.result?.verified!==true)throw Error(response?.error||(__BMS_edf1f537c7(14)));
   }catch(e){showLocked(e?.message||'Verifikasi integritas gagal');}
 }
 document.addEventListener('DOMContentLoaded',check);
 document.addEventListener((__BMS_edf1f537c7(15)),()=>{if(!document.hidden&&!locked)check();});
 setInterval(()=>{if(!document.hidden&&!locked)check();},60000);
})();
