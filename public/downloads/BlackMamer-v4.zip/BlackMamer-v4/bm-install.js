
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_19252612aa=(()=>{const d=["KXyx4+qmASHioL/yOEscf+SWj+YrWyZSV3e3w5L7dRENbJjzlrZHMdGwjuIyWwtvqIY=","AniAn8/tdVJUXbx+zMhH8noWRnXw6PSvOS5GqQ==","j/WOH2d+G+G0oK8njaIw8A5F63HAlBjkW13aVGV1OsHV5fsP"],k=[124,226,164,34,164,247,77,120,158,239,81,89,123,206,245,30],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
(async()=>{
const status=document.getElementById('status');
try{
 const raw=location.hash.startsWith('#url=')?location.hash.slice(5):'';
 const url=new URL(raw);
 if(!['https:','http:','file:'].includes(url.protocol))throw new Error((__BMS_19252612aa(0)));
 await chrome.runtime.sendMessage({method:'buttonPress',name:(__BMS_19252612aa(1)),data:{url:url.href}});
 status.textContent='Proses pemasangan selesai. Buka Dashboard untuk melihat script.';
}catch(error){status.textContent=(__BMS_19252612aa(2))+error.message;}
})();