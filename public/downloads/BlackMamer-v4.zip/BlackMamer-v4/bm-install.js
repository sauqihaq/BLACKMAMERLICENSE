
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_384fa20b4c=(()=>{const d=["04ZHFeaqRGRaGMKPSjk/XEc1tN2E9May78+W4kMqr8v3lm4FmroCdGkI859AKShMCyU=","R1s4PLLWB/13vR/G9+noI5rM/o/RHiWj42u8EQ==","/SStxcSEIBcbrE9iNRoRjd83MVI6N+7fV/KftN3NR+CnNNjV"],k=[134,20,168,103,28,138,63,91,61,212,254,185,195,239,36,196],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
(async()=>{
const status=document.getElementById('status');
try{
 const raw=location.hash.startsWith('#url=')?location.hash.slice(5):'';
 const url=new URL(raw);
 if(!['https:','http:','file:'].includes(url.protocol))throw new Error((__BMS_384fa20b4c(0)));
 await chrome.runtime.sendMessage({method:'buttonPress',name:(__BMS_384fa20b4c(1)),data:{url:url.href}});
 status.textContent='Proses pemasangan selesai. Buka Dashboard untuk melihat script.';
}catch(error){status.textContent=(__BMS_384fa20b4c(2))+error.message;}
})();