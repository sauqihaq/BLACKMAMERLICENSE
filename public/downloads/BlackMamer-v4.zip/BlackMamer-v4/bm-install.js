(async()=>{
const status=document.getElementById('status');
try{
 const raw=location.hash.startsWith('#url=')?location.hash.slice(5):'';
 const url=new URL(raw);
 if(!['https:','http:','file:'].includes(url.protocol))throw new Error('URL userscript tidak valid.');
 await chrome.runtime.sendMessage({method:'buttonPress',name:'installFromUrl',data:{url:url.href}});
 status.textContent='Proses pemasangan selesai. Buka Dashboard untuk melihat script.';
}catch(error){status.textContent='Pemasangan gagal: '+error.message;}
})();