
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_b91e92a1f3=(()=>{const d=["5YdIPUM3Kl7BrjFfRhZ8DjpfUCP5ig==","fQmOVmIoKIMlO3VXCZSW/BzBb46sNvo+7lG9pw==","0vv/yK6F3j9lMclYpKxsXQAYPAA7XcYhyoylMmtcl52I64rY"],k=[135,60,53,93,170,90,16,9,87,42,128,63,82,146,251,201],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
(async()=>{
const status=document.getElementById('status');
try{
 const raw=location.hash.startsWith('#url=')?location.hash.slice(5):'';
 const url=new URL(raw);
 if(!['https:','http:','file:'].includes(url.protocol))throw new Error('URL userscript tidak valid.');
 await chrome.runtime.sendMessage({method:(__BMS_b91e92a1f3(0)),name:(__BMS_b91e92a1f3(1)),data:{url:url.href}});
 status.textContent='Proses pemasangan selesai. Buka Dashboard untuk melihat script.';
}catch(error){status.textContent=(__BMS_b91e92a1f3(2))+error.message;}
})();