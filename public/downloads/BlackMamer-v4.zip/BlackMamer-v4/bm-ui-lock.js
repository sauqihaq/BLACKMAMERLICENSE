/* BLACKMAMERSTUDIO official signed UI — engine enforces the lock. */
(()=>{
 'use strict';let locked=false;
 function showLocked(message){
   if(locked)return;locked=true;
   const overlay=document.createElement('div');overlay.className='bm-integrity-overlay';
   const box=document.createElement('div');box.className='bm-integrity-box';
   const title=document.createElement('strong');title.textContent='BLACKMAMERSTUDIO · EXTENSION TERKUNCI';
   const body=document.createElement('p');body.textContent=message||'File extension atau identitas BLACKMAMER telah berubah. Install ulang paket resmi.';
   const note=document.createElement('small');note.textContent='Perubahan UI atau branding pada build resmi tidak diperbolehkan. Data pribadi tidak dihapus.';
   box.append(title,body,note);overlay.append(box);document.body.append(overlay);
 }
 async function check(){
   try{const response=await chrome.runtime.sendMessage({bm:{action:'brand-check'}});
     if(!response?.ok||response.result?.verified!==true)throw Error(response?.error||'Verifikasi build gagal');
   }catch(e){showLocked(e?.message||'Verifikasi integritas gagal');}
 }
 document.addEventListener('DOMContentLoaded',check);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!locked)check();});
 setInterval(()=>{if(!document.hidden&&!locked)check();},60000);
})();
