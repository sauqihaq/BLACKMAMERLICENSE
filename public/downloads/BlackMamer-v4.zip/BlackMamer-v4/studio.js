(() => {
 'use strict';const $=id=>document.getElementById(id),el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
 let state={scripts:[]},filter='all',editing=null,dirty=false,timer;
 const template='// ==UserScript==\n// @name         My userscript\n// @namespace    blackmamer-personal\n// @version      1.0\n// @description  My browser, my workflow.\n// @match        https://example.com/*\n// @grant        none\n// ==/UserScript==\n\n(function () {\n  \'use strict\';\n\n  // Your code here.\n})();\n';
 async function api(action,data={}){const r=await chrome.runtime.sendMessage({bm:{action,...data}});if(!r?.ok)throw Error(r?.error||'Engine tidak merespons.');return r.result;}
 function toast(text){$('toast').textContent=text;$('toast').hidden=false;clearTimeout(timer);timer=setTimeout(()=>$('toast').hidden=true,5500);}
 function show(name){for(const id of ['library','editor','install','settings'])$(id+'-view').hidden=id!==name;$('breadcrumb').textContent={library:'Script library',editor:'Personal editor',install:'Install product',settings:'Preferences'}[name];}
 async function refresh(){try{state=await api('state');$('version').textContent=state.version;$('engine-toggle').setAttribute('aria-checked',String(state.enabled));$('engine-label').textContent=state.enabled?'Engine active':'Engine paused';$('permission-banner').hidden=state.scriptsAllowed;$('nav-count').textContent=state.scripts.length;$('total-count').replaceChildren(document.createTextNode(state.scripts.length+' '),el('em','scripts'));$('active-count').replaceChildren(document.createTextNode(state.scripts.filter(s=>s.enabled).length+' '),el('em','enabled'));$('paid-count').replaceChildren(document.createTextNode(state.scripts.filter(s=>s.paid).length+' '),el('em','products'));render();}catch(e){toast(e.message);}}
 function selectFilter(value){filter=value;show('library');document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===value));document.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter===value));render();}
 const licenseClock = new Intl.DateTimeFormat('id-ID', {
   day: 'numeric', month: 'long', year: 'numeric',
   hour: '2-digit', minute: '2-digit', timeZoneName: 'short'
 });

 function updateLicenseLabel(label, license, now = Date.now()) {
   const status = license?.status === 'active' ? 'Lisensi aktif' : 'Perlu verifikasi';
   if (license?.expiresAt === null) {
     label.textContent = status + ' · Seumur hidup';
     return;
   }
   const end = Date.parse(license?.expiresAt);
   if (!Number.isFinite(end)) {
     label.textContent = status + ' · Tanggal berakhir belum tersedia';
     return;
   }
   const expired = end <= now;
   label.classList.toggle('expired', expired);
   const prefix = expired ? 'Lisensi berakhir' : status + ' · Berlaku sampai';
   label.textContent = prefix + ' ' + licenseClock.format(end);
 }

 function updateVisibleLicenses() {
   if (document.hidden) return;
   const licenses = new Map(state.scripts.filter(s => s.paid).map(s => [s.id, s.license]));
   for (const label of document.querySelectorAll('[data-license-id]')) {
     updateLicenseLabel(label, licenses.get(label.dataset.licenseId));
   }
 }

 setInterval(updateVisibleLicenses, 15000);
 chrome.storage.onChanged.addListener((changes, area) => {
   if (area === 'local' && changes.bmPurchases && !document.hidden) refresh();
 });
 document.addEventListener('visibilitychange', () => {
   if (!document.hidden) refresh();
 });
 function render(){const term=$('search').value.toLowerCase(),items=state.scripts.filter(s=>(filter==='all'||(filter==='paid')===s.paid)&&(s.name+' '+s.description).toLowerCase().includes(term));$('script-list').replaceChildren();for(const s of items){
  const row=el('article',undefined,'script-row'+(s.paid?' paid':'')),icon=el('div',s.paid?'◇':'⌘','script-icon'),info=el('div',undefined,'script-info'),title=el('h3',s.name),badge=el('span',s.paid?'LICENSED':'PERSONAL','badge');title.append(badge);
  info.append(title, el('p', 'v' + s.version + (s.paid ? '' : ' · ' + (s.description || 'Script buatan sendiri'))));
  if (s.paid) {
    const label = el('p', undefined, 'license-expiry');
    label.dataset.licenseId = s.id;
    updateLicenseLabel(label, s.license);
    info.append(label);
  }
  const actions=el('div',undefined,'script-actions'),toggle=el('button',undefined,'switch');toggle.setAttribute('role','switch');toggle.setAttribute('aria-label','Aktifkan '+s.name);toggle.setAttribute('aria-checked',String(s.enabled));toggle.onclick=async()=>{toggle.disabled=true;try{await api('toggle',{id:s.id,enabled:!s.enabled});await refresh();}catch(e){toast(e.message);}finally{toggle.disabled=false;}};actions.append(toggle);
  if(!s.paid){const edit=el('button','Edit');edit.onclick=()=>openEditor(s.id);actions.append(edit);const exp=el('button','↓');exp.title='Export userscript';exp.onclick=async()=>{try{const r=await api('source',{id:s.id});download(r.source,s.name.replace(/[^\w.-]/g,'_')+'.user.js','text/javascript');}catch(e){toast(e.message);}};actions.append(exp);}
  const remove=el('button','×');remove.title='Hapus '+s.name;remove.onclick=async()=>{if(!confirm('Hapus '+s.name+' dari browser ini?'))return;try{await api('remove',{id:s.id});await refresh();}catch(e){toast(e.message);}};actions.append(remove);row.append(icon,info,actions);$('script-list').append(row);
 }if(!items.length){const box=el('div',undefined,'empty');box.append(el('div','⌘','empty-symbol'),el('h3',term?'Tidak ada hasil.':'A fresh start.'),el('p',term?'Coba nama atau kata kunci lain.':'Buat script pertamamu, atau pasang produk dari link pembelian BlackMamer.'));const b=el('button','＋ Buat script pertama','secondary');b.onclick=()=>openEditor();box.append(b);$('script-list').append(box);} $('list-summary').textContent=items.length+' dari '+state.scripts.length+' script';}
 function download(data,name,type){const url=URL.createObjectURL(new Blob([data],{type})),a=el('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 async function openEditor(id,source){try{editing=id||null;$('code').value=source??(id?(await api('source',{id})).source:template);$('editor-title').textContent=id?'Edit userscript.':'New userscript.';dirty=false;lines();show('editor');$('code').focus();}catch(e){toast(e.message);}}
 function lines(){const count=$('code').value.split('\n').length;$('line-numbers').textContent=Array.from({length:count},(_,i)=>i+1).join('\n');$('editor-meta').textContent=count+' LINES · UTF-8'+(dirty?' · UNSAVED':'');}
 async function save(){const b=$('save-script');b.disabled=true;try{const r=await api('save',{id:editing||undefined,source:$('code').value});editing=r.id;dirty=false;lines();toast('Script disimpan. Muat ulang situs tujuan untuk menjalankannya.');await refresh();}catch(e){toast(e.message);}finally{b.disabled=false;}}
 $('code').addEventListener('input',()=>{dirty=true;lines();});$('code').addEventListener('scroll',()=>{$('line-numbers').scrollTop=$('code').scrollTop;});$('code').addEventListener('keydown',e=>{if(e.key==='Tab'){e.preventDefault();const t=e.target;t.setRangeText('  ',t.selectionStart,t.selectionEnd,'end');dirty=true;lines();}});
 document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key==='s'&&!$('editor-view').hidden){e.preventDefault();save();}});window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
 $('save-script').onclick=save;$('new-script').onclick=()=>openEditor();$('editor-back').onclick=()=>{if(dirty&&!confirm('Tinggalkan perubahan yang belum disimpan?'))return;dirty=false;show('library');};
 for(const b of document.querySelectorAll('[data-view],[data-filter]'))b.onclick=()=>{if(dirty&&!confirm('Tinggalkan perubahan yang belum disimpan?'))return;dirty=false;selectFilter(b.dataset.view||b.dataset.filter);};
 $('search').oninput=render;$('settings-open').onclick=()=>show('settings');$('engine-toggle').onclick=async()=>{try{await api('enabled',{enabled:!state.enabled});await refresh();}catch(e){toast(e.message);}};
 $('extension-settings').onclick=()=>chrome.tabs.create({url:'chrome://extensions/?id='+chrome.runtime.id});
 $('import-script').onclick=()=>$('import-file').click();$('import-file').onchange=async e=>{const f=e.target.files[0];if(f){if(f.size>1048576)return toast('File maksimal 1 MB.');await openEditor(null,await f.text());}e.target.value='';};
 $('export-personal').onclick=async()=>{try{download(JSON.stringify((await api('export')).backup,null,2),'BlackMamer-personal-backup.json','application/json');toast('Cadangan pribadi diunduh.');}catch(e){toast(e.message);}};
 const pending=new URLSearchParams(location.search).get('install');
 $('cancel-install').onclick=()=>{history.replaceState(null,'','dashboard.html');show('library');};
 $('confirm-install').onclick=async()=>{const b=$('confirm-install');b.disabled=true;try{const r=await api('claim',{id:pending});$('install-result').textContent=r.name+' berhasil dipasang. Buka atau muat ulang situs tujuan.';b.textContent='Installed ✓';await refresh();}catch(e){$('install-result').textContent=e.message;b.disabled=false;}};
 refresh();if(pending){show('install');api('pending',{id:pending}).then(({link})=>{$('install-name').textContent=link.name;$('install-version').textContent='Version '+link.version;for(const [label,value] of [['Link berakhir',new Date(link.expiresAt).toLocaleString('id-ID')],['Lisensi',link.licenseExpiresAt?new Date(link.licenseExpiresAt).toLocaleDateString('id-ID'):'Lifetime']])$('install-details').append(el('dt',label),el('dd',value));$('install-scopes').textContent='SITUS YANG DIAKSES\n'+link.matches.join('\n');$('confirm-install').disabled=!['ready','claimed'].includes(link.status);if($('confirm-install').disabled)$('install-result').textContent='Link tidak aktif. Hubungi admin.';}).catch(e=>{$('install-name').textContent='Pemasangan tidak tersedia';$('install-result').textContent=e.message;});}
})();
