
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_0df5567132=(()=>{const d=["76pEKtSzKEHxn147UHCh1RN68JT/nnYdm7vCr4LnGmjfukk606M+UeGPWCtOYA==","adKjcxCfW5f7El+yoKSx7ipvh6M=","rekvZpWofChjte1HQ50bOQN+jttZeNKWWpi+G0+5","Fj46d67QD3EYmXuR4xAmsKuqMODUbQ==","5bbioL3qM2Prr20t9bY=","b0OqmSM9qHJd14x0YJpunMYfZr2PqYDl","QpWbFES07qai7Axh7q1BI0m43UgekBUyTns=","hCoYsrRGGZ7wOPVxM9rBe8SXlJ8dGsW6RKw=","VHC1nqiQcBOYsYCl0uFGbo6g","82VKqUUvHLSeRBGc3zZGf67Yb3nRkQ==","QHTf0QR2n5gfkukRCL8=","baH77QZi36x1LDu5n0s=","rJg3OnlzydRjdcGVkJ0MHKa8oK7C5A==","PBWgs0unWO/OYCCifyI8u7ZJYJfxMwN43t0=","WLLERtOdyjmMfg3b2ng=","tZnEkVwQjLAVqt3geW2woQMnT7zlTEmUpS6hZzDAiGE=","Gq4NLgO3gkVqk943jXww2Zh+JJBmmuQZT6dKswf7","u9b2d8Wb/pNuHsK+JagT4pZrOadhJW++51I+iq0sMmXDxhhnp4u6g10O+a4euBHyintltyU1eK7gYi+6uRwtVdL2AFc=","GOyYYSWt3SPcuEJI9pCrMqF7Kdz0fWeN9IUFBMKkfbY=","lzuKcA/VsHqulPWecx0=","T7JepBzulW9co8EhTrq9Tg==","ykcRnYY54n8M2Nd5fJE+mQ==","pJJmEaG/HqtM4+1sHqayJq+/OE2Ti5Iv1WQUwY1mG4iJgnEBqq8Vu0Xz","3S2PtiBKhZJgNHN95t4Mf1CTCZuOBlmmwrBU+g==","y3Q2miecrB9GvROpVuXaai+kpiQ=","VmDnougirLtvSe+XZDP8eAjd2mJwjD6G","xnF02rZ7KZetn1kay7oNrEnm0ndlu5o5i6IRVruO","uKVh4ZZuX6DgIO69CU+6lUkxX2bYw2xgb44JgM8DBqGBtUrx","JJysNup/TNhSfvKQ95p4GdKnh7OO+xR0w75XPpunIlX2g0cnGWz9yQlu+YDoimYJypeXg5PLEUTbjlwOhZc=","nOEUvpioqeI+a4mnySXWvklSlooNLJFlZ8bpZx2LR4P1DlCuq7ih8i57","OrnqS0SRQTUSeoTfSnw=","EJVVndccBLyfrh/ksmkxpYg74qBfUPWI","76NuIfq6FU7QlmkwfXmYwj9jwI/fhw==","WNuQeCOWf5iSG2+5ka2W+Q52tbilOA==","l+ACbbShQSdSvNVML5R/Ljpnr8B/YfuJf4GcADWg0bqU8Fx9w7E5Nyas8VwKhAceQlfC8AFRxrkMseQwP5CaitfAIU3SgT0HKJy0bA60FQ4TR8ngGEGCqRqh9iBbgLKa8dBfXfyRGRcejJB8MaQgfmI34pAoMb/ZPtGDUA==","CjcBfIXZLH5wkIebEwbFpkqw0Po1c+6/","mL2CqdblRGqNpBUklaE=","j0hAkM0yVXu83Ht9gI2UhS4EgaR9tg==","BZ7wHSW7iK/e52xo27ouOiajplE2jycr","RCAyvZpPJJXRMcJmHsPzYOSOooAlAw==","TnmdkZCZGhi8uK6y6/hjdbu5ND/jpEFUiow5JnVvx8hraYyBj4kDCOuopoL2yHZFTYmKD1GUpGRzvM4WnV91+J5ZfbFtufQ4VphfkgbYhlUFmQ==","y2xspnMmL7+zTW6L5S8=","YH353iJ/opMmm9MG/KVMsVn9vnIGvP08/Kk=","G66Q5HNpqaUQO1Cg/FBLiA==","cpfdM594NN2MYmmMK4bxBUyjULcY/5xwV7I=","ZBrMujisI+aidwi7QzkaopVWEY6MKCVhxsoXa66H+49YCvqqCbxT9sBHNIstCTiS","47xkTOeU7C65ZzDAo2Foif6BCQDWoA==","h5Dtmm8Zo6crs5D7TnSYvjQ+dKeOVXCDiyeSbBDJrm67gPCKcgn9lzKDrMtcRI6ONA6Gl31lmrNtF39c/fk=","fqf7JXC+mVJNiuQsoWUXxq5nCotGg9kOZq5zuA==","0t8PfLaS/oROB+ClDrG5/GVx0L3SM5ioDljYgA==","FOfzaFO6qjq6ozBRjI+CK89gDMWCag+Ej45sDbirDr9K9+Z4CIroCoCTNGGEv5obk1Bd9YJaF7Savj09lpsqj3XHxUg2mo0anoMQcbGvrAujQH/lr0oypKquXi3LizufcdfLWHPqiWqM808B","fzB2eejCTWNMjxWHmgI=","CrkZrUz5xHYTuJ44B6W0VzGNhinabn7L+2gThhiI","LE3Ri0Yv4mQKwdZmc4hygg==","m5tMBp2mPLA8+ttze7+CPZumElqvgrok6W0=","+CSooRBTtIlPLUxiz8csZHGKNIyqD3Gt+blh9Yx6","6X0IjQ+FhAQmpDq2c/w=","NHeau485y6JLVp6OASjUYWLKv2sGh06P/gpQqr68","L2aFw0hgzY4fgLkDYqHLtYXxKn7GsGkwaa31X0aFXSFdVtzzflDDvk2wqDNVkfiFvcFRTreAXABfndhvcbUlEQ=="],k=[170,43,177,66,155,62,118,210,114,157,148,22,183,162,233,103],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
(() => {
 'use strict';const $=id=>document.getElementById(id),el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
 let state={scripts:[]},filter='all',editing=null,dirty=false,timer;
 const template="// ==UserScript==\n// @name         My BMscript\n// @namespace    blackmamer-personal\n// @version      1.0\n// @description  My browser, my workflow.\n// @match        https://example.com/*\n// @grant        none\n// ==/UserScript==\n\n(function () {\n  'use strict';\n\n  // Your code here.\n})();\n";
 async function api(action,data={}){const r=await chrome.runtime.sendMessage({bm:{action,...data}});if(!r?.ok)throw Error(r?.error||(__BMS_0df5567132(0)));return r.result;}
 function toast(text){$('toast').textContent=text;$('toast').hidden=false;clearTimeout(timer);timer=setTimeout(()=>$('toast').hidden=true,5500);}
 function show(name){for(const id of ['library','editor','install','settings'])$(id+'-view').hidden=id!==name;$((__BMS_0df5567132(1))).textContent={library:'Script library',editor:'Personal editor',install:(__BMS_0df5567132(2)),settings:(__BMS_0df5567132(3))}[name];}
 async function refresh(){try{state=await api('state');$((__BMS_0df5567132(4))).textContent=state.version;$('engine-toggle').setAttribute('aria-checked',String(state.enabled));$((__BMS_0df5567132(5))).textContent=state.enabled?(__BMS_0df5567132(6)):(__BMS_0df5567132(7));$('permission-banner').hidden=state.scriptsAllowed;$((__BMS_0df5567132(8))).textContent=state.scripts.length;$((__BMS_0df5567132(9))).replaceChildren(document.createTextNode(state.scripts.length+' '),el('em',(__BMS_0df5567132(10))));$('active-count').replaceChildren(document.createTextNode(state.scripts.filter(s=>s.enabled).length+' '),el('em',(__BMS_0df5567132(11))));$('paid-count').replaceChildren(document.createTextNode(state.scripts.filter(s=>s.paid).length+' '),el('em','products'));render();}catch(e){toast(e.message);}}
 function selectFilter(value){filter=value;show('library');document.querySelectorAll((__BMS_0df5567132(12))).forEach(b=>b.classList.toggle('active',b.dataset.view===value));document.querySelectorAll((__BMS_0df5567132(13))).forEach(b=>b.classList.toggle('active',b.dataset.filter===value));render();}
 const licenseClock = new Intl.DateTimeFormat('id-ID', {
   day: 'numeric', month: 'long', year: 'numeric',
   hour: (__BMS_0df5567132(14)), minute: '2-digit', timeZoneName: 'short'
 });

 function updateLicenseLabel(label, license, now = Date.now()) {
   const status = license?.status === 'active' ? 'Lisensi aktif' : (__BMS_0df5567132(15));
   if (license?.expiresAt === null) {
     label.textContent = status + (__BMS_0df5567132(16));
     return;
   }
   const end = Date.parse(license?.expiresAt);
   if (!Number.isFinite(end)) {
     label.textContent = status + (__BMS_0df5567132(17));
     return;
   }
   const expired = end <= now;
   label.classList.toggle('expired', expired);
   const prefix = expired ? (__BMS_0df5567132(18)) : status + ' · Berlaku sampai';
   label.textContent = prefix + ' ' + licenseClock.format(end);
 }

 function updateVisibleLicenses() {
   if (document.hidden) return;
   const licenses = new Map(state.scripts.filter(s => s.paid).map(s => [s.id, s.license]));
   for (const label of document.querySelectorAll('[data-license-id]')) {
     updateLicenseLabel(label, licenses.get(label.dataset.licenseId));
   }
 }

 setInterval(updateVisibleLicenses, 15000);
 chrome.storage.onChanged.addListener((changes, area) => {
   if (area === 'local' && changes.bmPurchases && !document.hidden) refresh();
 });
 document.addEventListener('visibilitychange', () => {
   if (!document.hidden) refresh();
 });
 function render(){const term=$('search').value.toLowerCase(),items=state.scripts.filter(s=>(filter==='all'||(filter==='paid')===s.paid)&&(s.name+' '+s.description).toLowerCase().includes(term));$('script-list').replaceChildren();for(const s of items){
  const row=el((__BMS_0df5567132(19)),undefined,'script-row'+(s.paid?' paid':'')),icon=el('div',s.paid?'◇':'⌘','script-icon'),info=el('div',undefined,'script-info'),title=el('h3',s.name),badge=el('span',s.paid?(__BMS_0df5567132(20)):(__BMS_0df5567132(21)),'badge');title.append(badge);
  info.append(title, el('p', 'v' + s.version + (s.paid ? '' : ' · ' + (s.description || (__BMS_0df5567132(22))))));
  if (s.paid) {
    const label = el('p', undefined, (__BMS_0df5567132(23)));
    label.dataset.licenseId = s.id;
    updateLicenseLabel(label, s.license);
    info.append(label);
  }
  const actions=el('div',undefined,'script-actions'),toggle=el('button',undefined,'switch');toggle.setAttribute('role','switch');toggle.setAttribute((__BMS_0df5567132(24)),'Aktifkan '+s.name);toggle.setAttribute((__BMS_0df5567132(25)),String(s.enabled));toggle.onclick=async()=>{toggle.disabled=true;try{await api('toggle',{id:s.id,enabled:!s.enabled});await refresh();}catch(e){toast(e.message);}finally{toggle.disabled=false;}};actions.append(toggle);
  if(!s.paid){const edit=el('button','Edit');edit.onclick=()=>openEditor(s.id);actions.append(edit);const exp=el('button','↓');exp.title=(__BMS_0df5567132(26));exp.onclick=async()=>{try{const r=await api('source',{id:s.id});download(r.source,s.name.replace(/[^\w.-]/g,'_')+'.user.js','text/javascript');}catch(e){toast(e.message);}};actions.append(exp);}
  const remove=el('button','×');remove.title='Hapus '+s.name;remove.onclick=async()=>{if(!confirm('Hapus '+s.name+(__BMS_0df5567132(27))))return;try{await api('remove',{id:s.id});await refresh();}catch(e){toast(e.message);}};actions.append(remove);row.append(icon,info,actions);$('script-list').append(row);
 }if(!items.length){const box=el('div',undefined,'empty');box.append(el('div','⌘','empty-symbol'),el('h3',term?'Tidak ada hasil.':'A fresh start.'),el('p',term?(__BMS_0df5567132(28)):'Buat script pertamamu, atau pasang produk dari link pembelian BlackMamer.'));const b=el('button',(__BMS_0df5567132(29)),'secondary');b.onclick=()=>openEditor();box.append(b);$('script-list').append(box);} $('list-summary').textContent=items.length+' dari '+state.scripts.length+(__BMS_0df5567132(30));}
 function download(data,name,type){const url=URL.createObjectURL(new Blob([data],{type})),a=el('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 async function openEditor(id,source){try{editing=id||null;$('code').value=source??(id?(await api('source',{id})).source:template);$((__BMS_0df5567132(31))).textContent=id?"Edit BMscript.":"New BMscript.";dirty=false;lines();show('editor');$('code').focus();}catch(e){toast(e.message);}}
 function lines(){const count=$('code').value.split('\n').length;$('line-numbers').textContent=Array.from({length:count},(_,i)=>i+1).join('\n');$((__BMS_0df5567132(32))).textContent=count+' LINES · UTF-8'+(dirty?' · UNSAVED':'');}
 async function save(){const b=$((__BMS_0df5567132(33)));b.disabled=true;try{const r=await api('save',{id:editing||undefined,source:$('code').value});editing=r.id;dirty=false;lines();toast((__BMS_0df5567132(34)));await refresh();}catch(e){toast(e.message);}finally{b.disabled=false;}}
 $('code').addEventListener('input',()=>{dirty=true;lines();});$('code').addEventListener('scroll',()=>{$((__BMS_0df5567132(35))).scrollTop=$('code').scrollTop;});$('code').addEventListener((__BMS_0df5567132(36)),e=>{if(e.key==='Tab'){e.preventDefault();const t=e.target;t.setRangeText('  ',t.selectionStart,t.selectionEnd,'end');dirty=true;lines();}});
 document.addEventListener((__BMS_0df5567132(36)),e=>{if((e.ctrlKey||e.metaKey)&&e.key==='s'&&!$((__BMS_0df5567132(37))).hidden){e.preventDefault();save();}});window.addEventListener((__BMS_0df5567132(38)),e=>{if(dirty){e.preventDefault();e.returnValue='';}});
 $((__BMS_0df5567132(33))).onclick=save;$('new-script').onclick=()=>openEditor();$((__BMS_0df5567132(39))).onclick=()=>{if(dirty&&!confirm((__BMS_0df5567132(40))))return;dirty=false;show((__BMS_0df5567132(41)));};
 for(const b of document.querySelectorAll('[data-view],[data-filter]'))b.onclick=()=>{if(dirty&&!confirm((__BMS_0df5567132(40))))return;dirty=false;selectFilter(b.dataset.view||b.dataset.filter);};
 $('search').oninput=render;$((__BMS_0df5567132(42))).onclick=()=>show((__BMS_0df5567132(43)));$((__BMS_0df5567132(44))).onclick=async()=>{try{await api('enabled',{enabled:!state.enabled});await refresh();}catch(e){toast(e.message);}};
 $('extension-settings').onclick=()=>chrome.tabs.create({url:(__BMS_0df5567132(45))+chrome.runtime.id});
 $('import-script').onclick=()=>$((__BMS_0df5567132(46))).click();$((__BMS_0df5567132(46))).onchange=async e=>{const f=e.target.files[0];if(f){if(f.size>1048576)return toast('File maksimal 1 MB.');await openEditor(null,await f.text());}e.target.value='';};
 $('export-personal').onclick=async()=>{try{download(JSON.stringify((await api('export')).backup,null,2),(__BMS_0df5567132(47)),'application/json');toast('Cadangan pribadi diunduh.');}catch(e){toast(e.message);}};
 const pending=new URLSearchParams(location.search).get('install');
 $('cancel-install').onclick=()=>{history.replaceState(null,'',(__BMS_0df5567132(48)));show((__BMS_0df5567132(41)));};
 $('confirm-install').onclick=async()=>{const b=$('confirm-install');b.disabled=true;try{const r=await api('claim',{id:pending});$((__BMS_0df5567132(49))).textContent=r.name+(__BMS_0df5567132(50));b.textContent='Installed ✓';await refresh();}catch(e){$('install-result').textContent=e.message;b.disabled=false;}};
 refresh();if(pending){show((__BMS_0df5567132(51)));api('pending',{id:pending}).then(({link})=>{$('install-name').textContent=link.name;$((__BMS_0df5567132(52))).textContent=(__BMS_0df5567132(53))+link.version;for(const [label,value] of [[(__BMS_0df5567132(54)),new Date(link.expiresAt).toLocaleString('id-ID')],['Lisensi',link.licenseExpiresAt?new Date(link.licenseExpiresAt).toLocaleDateString('id-ID'):'Lifetime']])$((__BMS_0df5567132(55))).append(el('dt',label),el('dd',value));$('install-scopes').textContent='SITUS YANG DIAKSES\n'+link.matches.join('\n');$('confirm-install').disabled=!['ready',(__BMS_0df5567132(56))].includes(link.status);if($((__BMS_0df5567132(57))).disabled)$((__BMS_0df5567132(49))).textContent=(__BMS_0df5567132(58));}).catch(e=>{$('install-name').textContent='Pemasangan tidak tersedia';$('install-result').textContent=e.message;});}
})();
