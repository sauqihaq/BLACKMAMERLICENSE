
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_7a6eef39ad=(()=>{const d=["fzqA7idAKkNzHTZT3/+3wz5XSy/cvYTv+Ng3WnsecQNPKo3+IFA8U2MNMEPB7w==","a8QhXngk1LTt4HLRG1GSF9gE5DM=","IhA5Dbg4x+xARh9FIB/uUfrx5c3JVRYtqbu86c3a","rVYZ+FzGbFztIoKyiOK2029fwxnWBg==","htUXVUQTWAh7P6npBkU=","BEE6G+dVW/1fwQ5ZCCHhv9DtS940XKMc","sbaZ5sbXhlMtFRoKwz3652pLL0p9EuBat/Q=","7O6XQaJENBxLUNb+wcyiVjEsbbx26FXZgFk=","eV0OJYuzguH70nVQKxgtBR4w","AQ4pObDr5Uf1RoEeG1618KzO7VS5Kg==","ufu0x5RbWyPssevjitw=","qVQIFAQJXTwd6LRKiUk=","LhpfUvb838JOWHous77+7sXfVVs7HQ==","KueN0PBSexY8C0MyiubFSN1L8BU1W/D33Ms=","e0E2RLAfP1F18WbNSlU=","QCI9sjfiHNPRXy4ZewYyMWvjwE/zTmQWHkaC6MLW60w=","ij7J6vBEgEfoEbZfAvMmz7VTnytFuRbrLMS/Rv4C","ucB0Wq0gcbB47O/dnl0wG2QAWjeU4ZZNjFCuCGlEwerB0JpKzzA1oEv81M2lTTILeBAGJ9DxgV2LYL84fXTe2tDggno=","lxWOCgg9Zuf/S7BKlRJeWlj0QspkUKM2B6YH9kDHFUM=","LFOp//3D01dbLwy9GO8=","LNGrUeUX/gTMMwXlvUm/TA==","oUWBH0JREfAOzlVUFCqxug==","V7Fk4yPcdl7DGvsHMzYJ4oxMyk/wCWdHLOt/1x1L3zN6oXPzKMx9TsoK","tekARTZIqBDbXFDyFMhvUqUo8Ljl9MnFBkWnAw==","5lmNIQS/Xu0l3uZcrxyxAb80YuA=","pAuEMh3mVUgES38VoFsP9wrLWE8YN7Gl","P/4fzCZW7SxevFvoSdllWcYfxBxIKyH9qFHjVNgM","fFCSGJQF3TCI5GFOH02XF/JZfOkq1Q9NmjXwo6TxlsJFQLkI","ph7EXmXwWs5/U0kr1LmK67HEckZ3An8fUy6T+mhUIFd0AS9PluPr3yRDQjvLqZT7qfRidmoyei9LHpjKdmQ=","ihM53SNdihvMAOo3POEvTSJQBgjJRGLqZdBrSnUwyKDj/H3NEE2CC9wQ","GUoYSScTtF3r9e/J2lE=","5S6svrzulN9bW+wdsAKzNeD/bVNJUtgK","fzOq5QlJF0xSFAFY8vaO1BJOezT8pA==","Ws0SVUst8LuE6ULaKli1APwd1ihQ/A==","GBkUBpkx+uNxTydOTBaKRsPoxNbvTD8yjKKe8rfDuU8bCUoW7iGC8wVfA15pBvJ2u9ip5pF8AgL/kubCvfPyf1g5Nyb/EYbDC29Gbm024GbqyKL2iGxGEumC9NLZ49pvfilJNtEBotM9f2J+UibVFpu4iYa4HHtizfKBog==","sV8i83fPT1OFK364ePRVxY5FIwM3GGwv","+953XC8cLwEdNNHgZlI=","5ErQEglapvS+yvlQ6DYbpjj2rMfGQw==","9r3y76fY4FpRHnoD9iqV/gVQVFNVDdJD","LOS9ToxNCRdqWeHp7NWQTRE1W6NO8Q==","Y1QmKrO66Orf21tHEgEIHisp8PsQV0NWCA5RTvrg0d5GRDc6rKrx+ojLU3cPMR0u3RlOy6JnpmbxPqZ+EtBj7rN0xgpOmgbKNfuqZ/8h7T6VCQ==","OQcPNobi1kzYT/4JIUc=","mfKSyLJSZijVuNH0fsYkRNYEqBkrLEb431o=","31tjHXECKzV4/99T6lJmCg==","8BW1WxD3IsuhT9I3CKUD9y/ApULhBvcbxyI=","cujh2YNZAB9QHGsrtv3jUf5UgQxIQNbuxNyVRsY8dKxO+NfJsklwDzIsVxvYzcFh","wE+WToQWGUZA6FvWM0ysMg2iC/JUww==","cisUuQTrM8TvRmMCTB8aLlz6+1SYV10BME+x4+LfzUNOOwmpGftt9PZ2XzJeLwweXMoJZGtntzHWf1zTD+8=","7jc/4YNNm1DPCIxELuoB0INKsTBloCv8Bc2GTQ==","0MmNUd4pcadY9c3GtUSaBZcasy0n92FbZVpIAg==","mx7lA34qEf6ZUMJT7w13QzbvZ9MSR8s/fK1u/zrIZkrFDvATJRpTzqNgxmPnPW9zat824xJ30w9pnT/PFPhCevo+0yMbCjbevXDic9ItWWNazxTzP2f2H1mNXN9J6FNq/i7dM156Mq6vAL0D","xFhV9hrULk65NOyk8fA=","adrsWLUArx2DKFr89Fa2VbMP7kFV4Wjd1kWoPTur","R09BCYJHEesI11RLGzP9oQ==","aLhO9B/FVEWzA80YVi85+bhV4FjMAE9MEOI=","kOAnUgZRmQv0RW/tPdFPSYQxza/B/eHOPUySDI4R","xFCzNiymdvZFx89DigU=","xhz5K3r9MlEgVA4MxUAn7mDcPUZuPMGs6Ph9yQVJ","1unu1dhNCTXso7vx4MKjQAoIPBXrINL0Sl4HXSUHqEmk2bfl7n0HBb6TqsHX8pBwMjhHJZoQ58R8biptEjfQeQ==","Xkf7Abgepinv+1VXeFbiDo9OAuBN3nNEpTqSqoL6oMs=","RwgHRKbqmNA0Skow1KCK/LXNIE1lC38QRyeC8SFdJGAVOMx099qu4Dd6QwDAkJnMs/0rfWk7dSAiF4LBPW0pcG4oPmSJyrjwVmo=","8fVcxjNEqgTvGd8sVPgdWg9ZdAPVTXvlEdkKQVE57JfExQn2M3S9NPwpwBxIyAVqH2kjM7B9stWg6f9xtAldhyPVrObIZFMkCTl+DK7Y+XryedkjCW3yxaX54mGhGQz3OqXpltUURlQNSSt8vqjuCv4JyFMVHYq1ionaEZtpc+dBtb2G4ARrRCxZXmyMuM4ayBn2QyENlqWYmYsBkXkk1xWFiLb6NC90OWkHXISIzSrBKfFzIz2slQ==","T1MuUhYKj0LE7NbS5Ug7Poeunv6Bz4ZLLQ0LEoYl/M97YzJiYDr3cqHc7+KZeEsO457mzr3/","5Denpbj3g8B7QtAGyRuCIsf2jVmJXDIEREjX5oTktn4="],k=[58,239,66,64,25,86,249,196,95,38,183,228,212,87,16,12],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
(() => {
 'use strict';const $=id=>document.getElementById(id),el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
 let state={scripts:[]},filter='all',editing=null,dirty=false,timer;
 const template="// ==UserScript==\n// @name         My BMscript\n// @namespace    blackmamer-personal\n// @version      1.0\n// @description  My browser, my workflow.\n// @match        https://example.com/*\n// @grant        none\n// ==/UserScript==\n\n(function () {\n  'use strict';\n\n  // Your code here.\n})();\n";
 async function api(action,data={}){const r=await chrome.runtime.sendMessage({bm:{action,...data}});if(!r?.ok)throw Error(r?.error||(__BMS_7a6eef39ad(0)));return r.result;}
 function toast(text){$('toast').textContent=text;$('toast').hidden=false;clearTimeout(timer);timer=setTimeout(()=>$('toast').hidden=true,5500);}
 function show(name){for(const id of ['library','editor','install','settings'])$(id+'-view').hidden=id!==name;$((__BMS_7a6eef39ad(1))).textContent={library:'Script library',editor:'Personal editor',install:(__BMS_7a6eef39ad(2)),settings:(__BMS_7a6eef39ad(3))}[name];}
 async function refresh(){try{state=await api('state');$((__BMS_7a6eef39ad(4))).textContent=state.version;$('engine-toggle').setAttribute('aria-checked',String(state.enabled));$((__BMS_7a6eef39ad(5))).textContent=state.enabled?(__BMS_7a6eef39ad(6)):(__BMS_7a6eef39ad(7));$('permission-banner').hidden=state.scriptsAllowed;$((__BMS_7a6eef39ad(8))).textContent=state.scripts.length;$((__BMS_7a6eef39ad(9))).replaceChildren(document.createTextNode(state.scripts.length+' '),el('em',(__BMS_7a6eef39ad(10))));$('active-count').replaceChildren(document.createTextNode(state.scripts.filter(s=>s.enabled).length+' '),el('em',(__BMS_7a6eef39ad(11))));$('paid-count').replaceChildren(document.createTextNode(state.scripts.filter(s=>s.paid).length+' '),el('em','products'));render();}catch(e){toast(e.message);}}
 function selectFilter(value){filter=value;show('library');document.querySelectorAll((__BMS_7a6eef39ad(12))).forEach(b=>b.classList.toggle('active',b.dataset.view===value));document.querySelectorAll((__BMS_7a6eef39ad(13))).forEach(b=>b.classList.toggle('active',b.dataset.filter===value));render();}
 const licenseClock = new Intl.DateTimeFormat('id-ID', {
   day: 'numeric', month: 'long', year: 'numeric',
   hour: (__BMS_7a6eef39ad(14)), minute: '2-digit', timeZoneName: 'short'
 });

 function updateLicenseLabel(label, license, now = Date.now()) {
   const status = license?.status === 'active' ? 'Lisensi aktif' : (__BMS_7a6eef39ad(15));
   if (license?.expiresAt === null) {
     label.textContent = status + (__BMS_7a6eef39ad(16));
     return;
   }
   const end = Date.parse(license?.expiresAt);
   if (!Number.isFinite(end)) {
     label.textContent = status + (__BMS_7a6eef39ad(17));
     return;
   }
   const expired = end <= now;
   label.classList.toggle('expired', expired);
   const prefix = expired ? (__BMS_7a6eef39ad(18)) : status + ' · Berlaku sampai';
   label.textContent = prefix + ' ' + licenseClock.format(end);
 }

 function updateVisibleLicenses() {
   if (document.hidden) return;
   const licenses = new Map(state.scripts.filter(s => s.paid).map(s => [s.id, s.license]));
   for (const label of document.querySelectorAll('[data-license-id]')) {
     updateLicenseLabel(label, licenses.get(label.dataset.licenseId));
   }
 }

 setInterval(updateVisibleLicenses, 15000);
 chrome.storage.onChanged.addListener((changes, area) => {
   if (area === 'local' && changes.bmPurchases && !document.hidden) refresh();
 });
 document.addEventListener('visibilitychange', () => {
   if (!document.hidden) refresh();
 });
 function render(){const term=$('search').value.toLowerCase(),items=state.scripts.filter(s=>(filter==='all'||(filter==='paid')===s.paid)&&(s.name+' '+s.description).toLowerCase().includes(term));$('script-list').replaceChildren();for(const s of items){
  const row=el((__BMS_7a6eef39ad(19)),undefined,'script-row'+(s.paid?' paid':'')),icon=el('div',s.paid?'◇':'⌘','script-icon'),info=el('div',undefined,'script-info'),title=el('h3',s.name),badge=el('span',s.paid?(__BMS_7a6eef39ad(20)):(__BMS_7a6eef39ad(21)),'badge');title.append(badge);
  info.append(title, el('p', 'v' + s.version + (s.paid ? '' : ' · ' + (s.description || (__BMS_7a6eef39ad(22))))));
  if (s.paid) {
    const label = el('p', undefined, (__BMS_7a6eef39ad(23)));
    label.dataset.licenseId = s.id;
    updateLicenseLabel(label, s.license);
    info.append(label);
  }
  const actions=el('div',undefined,'script-actions'),toggle=el('button',undefined,'switch');toggle.setAttribute('role','switch');toggle.setAttribute((__BMS_7a6eef39ad(24)),'Aktifkan '+s.name);toggle.setAttribute((__BMS_7a6eef39ad(25)),String(s.enabled));toggle.onclick=async()=>{toggle.disabled=true;try{await api('toggle',{id:s.id,enabled:!s.enabled});await refresh();}catch(e){toast(e.message);}finally{toggle.disabled=false;}};actions.append(toggle);
  if(!s.paid){const edit=el('button','Edit');edit.onclick=()=>openEditor(s.id);actions.append(edit);const exp=el('button','↓');exp.title=(__BMS_7a6eef39ad(26));exp.onclick=async()=>{try{const r=await api('source',{id:s.id});download(r.source,s.name.replace(/[^\w.-]/g,'_')+'.user.js','text/javascript');}catch(e){toast(e.message);}};actions.append(exp);}
  const remove=el('button','×');remove.title='Hapus '+s.name;remove.onclick=async()=>{if(!confirm('Hapus '+s.name+(__BMS_7a6eef39ad(27))))return;try{await api('remove',{id:s.id});await refresh();}catch(e){toast(e.message);}};actions.append(remove);row.append(icon,info,actions);$('script-list').append(row);
 }if(!items.length){const box=el('div',undefined,'empty');box.append(el('div','⌘','empty-symbol'),el('h3',term?'Tidak ada hasil.':'A fresh start.'),el('p',term?(__BMS_7a6eef39ad(28)):'Buat script pertamamu, atau pasang produk dari link pembelian BlackMamer.'));const b=el('button',(__BMS_7a6eef39ad(29)),'secondary');b.onclick=()=>openEditor();box.append(b);$('script-list').append(box);} $('list-summary').textContent=items.length+' dari '+state.scripts.length+(__BMS_7a6eef39ad(30));}
 function download(data,name,type){const url=URL.createObjectURL(new Blob([data],{type})),a=el('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 async function openEditor(id,source){try{editing=id||null;$('code').value=source??(id?(await api('source',{id})).source:template);$((__BMS_7a6eef39ad(31))).textContent=id?"Edit BMscript.":"New BMscript.";dirty=false;lines();show('editor');$('code').focus();}catch(e){toast(e.message);}}
 function lines(){const count=$('code').value.split('\n').length;$('line-numbers').textContent=Array.from({length:count},(_,i)=>i+1).join('\n');$((__BMS_7a6eef39ad(32))).textContent=count+' LINES · UTF-8'+(dirty?' · UNSAVED':'');}
 async function save(){const b=$((__BMS_7a6eef39ad(33)));b.disabled=true;try{const r=await api('save',{id:editing||undefined,source:$('code').value});editing=r.id;dirty=false;lines();toast((__BMS_7a6eef39ad(34)));await refresh();}catch(e){toast(e.message);}finally{b.disabled=false;}}
 $('code').addEventListener('input',()=>{dirty=true;lines();});$('code').addEventListener('scroll',()=>{$((__BMS_7a6eef39ad(35))).scrollTop=$('code').scrollTop;});$('code').addEventListener((__BMS_7a6eef39ad(36)),e=>{if(e.key==='Tab'){e.preventDefault();const t=e.target;t.setRangeText('  ',t.selectionStart,t.selectionEnd,'end');dirty=true;lines();}});
 document.addEventListener((__BMS_7a6eef39ad(36)),e=>{if((e.ctrlKey||e.metaKey)&&e.key==='s'&&!$((__BMS_7a6eef39ad(37))).hidden){e.preventDefault();save();}});window.addEventListener((__BMS_7a6eef39ad(38)),e=>{if(dirty){e.preventDefault();e.returnValue='';}});
 $((__BMS_7a6eef39ad(33))).onclick=save;$('new-script').onclick=()=>openEditor();$((__BMS_7a6eef39ad(39))).onclick=()=>{if(dirty&&!confirm((__BMS_7a6eef39ad(40))))return;dirty=false;show((__BMS_7a6eef39ad(41)));};
 for(const b of document.querySelectorAll('[data-view],[data-filter]'))b.onclick=()=>{if(dirty&&!confirm((__BMS_7a6eef39ad(40))))return;dirty=false;selectFilter(b.dataset.view||b.dataset.filter);};
 $('search').oninput=render;$((__BMS_7a6eef39ad(42))).onclick=()=>show((__BMS_7a6eef39ad(43)));$((__BMS_7a6eef39ad(44))).onclick=async()=>{try{await api('enabled',{enabled:!state.enabled});await refresh();}catch(e){toast(e.message);}};
 $('extension-settings').onclick=()=>chrome.tabs.create({url:(__BMS_7a6eef39ad(45))+chrome.runtime.id});
 $('import-script').onclick=()=>$((__BMS_7a6eef39ad(46))).click();$((__BMS_7a6eef39ad(46))).onchange=async e=>{const f=e.target.files[0];if(f){if(f.size>1048576)return toast('File maksimal 1 MB.');await openEditor(null,await f.text());}e.target.value='';};
 $('export-personal').onclick=async()=>{try{download(JSON.stringify((await api('export')).backup,null,2),(__BMS_7a6eef39ad(47)),'application/json');toast('Cadangan pribadi diunduh.');}catch(e){toast(e.message);}};
 const pending=new URLSearchParams(location.search).get('install');
 $('cancel-install').onclick=()=>{history.replaceState(null,'',(__BMS_7a6eef39ad(48)));show((__BMS_7a6eef39ad(41)));};
 $('confirm-install').onclick=async()=>{const b=$('confirm-install');b.disabled=true;try{const r=await api('claim',{id:pending});$((__BMS_7a6eef39ad(49))).textContent=r.name+(__BMS_7a6eef39ad(50));b.textContent='Installed ✓';await refresh();}catch(e){$('install-result').textContent=e.message;b.disabled=false;}};
 refresh();if(pending){show((__BMS_7a6eef39ad(51)));api('pending',{id:pending}).then(({link})=>{$('install-name').textContent=link.name;$((__BMS_7a6eef39ad(52))).textContent=(__BMS_7a6eef39ad(53))+link.version;for(const [label,value] of [[(__BMS_7a6eef39ad(54)),new Date(link.expiresAt).toLocaleString('id-ID')],['Lisensi',link.licenseExpiresAt?new Date(link.licenseExpiresAt).toLocaleDateString('id-ID'):'Lifetime']])$((__BMS_7a6eef39ad(55))).append(el('dt',label),el('dd',value));$('install-scopes').textContent='SITUS YANG DIAKSES\n'+link.matches.join('\n');$('confirm-install').disabled=!['ready',(__BMS_7a6eef39ad(56))].includes(link.status);if($((__BMS_7a6eef39ad(57))).disabled)$((__BMS_7a6eef39ad(49))).textContent=(__BMS_7a6eef39ad(58));}).catch(e=>{$('install-name').textContent='Pemasangan tidak tersedia';$('install-result').textContent=e.message;});}
})();

/* BLACKMAMERSTUDIO official signed UI — engine enforces the lock. */
(()=>{
 'use strict';let locked=false;
 function showLocked(message){
   if(locked)return;locked=true;
   const overlay=document.createElement('div');overlay.className='bm-integrity-overlay';
   const box=document.createElement('div');box.className=(__BMS_7a6eef39ad(59));
   const title=document.createElement('strong');title.textContent=(__BMS_7a6eef39ad(60));
   const body=document.createElement('p');body.textContent=message||'File extension atau identitas BLACKMAMER telah berubah. Install ulang paket resmi.';
   const note=document.createElement('small');note.textContent=(__BMS_7a6eef39ad(61));
   box.append(title,body,note);overlay.append(box);document.body.append(overlay);
 }
 async function check(){
   try{const response=await chrome.runtime.sendMessage({bm:{action:'brand-check'}});
     if(!response?.ok||response.result?.verified!==true)throw Error(response?.error||'Verifikasi build gagal');
   }catch(e){showLocked(e?.message||(__BMS_7a6eef39ad(62)));}
 }
 document.addEventListener((__BMS_7a6eef39ad(63)),check);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!locked)check();});
 setInterval(()=>{if(!document.hidden&&!locked)check();},60000);
})();
