
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_e0b46f8999=(()=>{const d=["K0fWvwJg4pDjgnMB36Y=","s4Ki1zxymP2u+/RCU5g=","Qe90YDZFkb0BZgaWuIB0Aw==","+wRQoUeA/9UkdH375fnLQD6W4+YFaw==","FUbenLvsNWUGQvi4JmU=","aZJHhLYHe6SMh5HQWneg9pj2x01glerj42w=","tf9W/VdE3Jo36lpnAkCotiNrK5nijTsI","mr/DYfeXvYMFAp+n14oi3/Z6kvUG8zlK","+9RXc9X61vpnQbaZxec=","NWOxRGy6D2eVlfyBXwyTqW+Ia93CfA==","B6KXgf/SCnXb+CX4Ek8=","zZ0j68RkzEFWuahq3ZqZjCkPu6y0jwDY2n++7iPuHFU=","yoXeAO6luYTH0W946/fr9VJMh5K54nRvWki1rnlzg4GSlRAQrLXdlDTBlGgQ5wnlrlw7gh3yg3+9WESejUN8sWOl6CA=","UvwYQ7ebL+k0ZphPQbc=","W2FklyaA6wOMqE+LL9zSewfy8fLgSX6Rz/+kcLNVGa2tdg==","uHTV+1z5ZECWlkLmu2s=","m0Nmu7NkRZRcjsINc6pRiQ==","GYY/0612Ffkv93xOj5R85GttxEoJsGpt6oOBlyoW77MUlgjDhmY+6Qbn","4+rTZ5tANLb1a7SZDo3VCKCtJow=","WgH5puaFQN6XefT0cfRbS+2T","00JPmDjopGmWTie0umlan1WLzgptr1iSZMeRYlXtUuvqUmSI","3ZaZgCcDEKn3iPfdb3yE8/TxpEgWjoT+gnNjVA==","Z/i7+KxPLJfK5adq+0tQs9FskJx2lrsV3LJHkTPCgGVV6LDov199h5H1rHrkW06jyXyAjEumniXkgmyhDfI=","ybhFZXKbMI/DDhmrCY6j22B+B/GM7/1WVYyb/Hx1bFL6qG11QosZn6Yedrt6noDLTW4m4b3fzWZlvK/MTUVJYsWYd0UTuxSvsS4liy6uhPtCXnfRvM+cdnest9wOVVRy0ogOVSirNL/DPl+bV77j6zxOS8HBv+wGG9yOrBwlJAKq+BMlONtJz8JOR+tPzuObZz4=","BS+Jd2b2Ufb6TTeVEePNbMRJLbHpcgCCFpTBFza0AJdMwO1ndeZ55spd","rWYAT963pGgqmAWK+Ak4rsON","pad5ikjfoXpl9Yzzgko=","Q5mz51FoEE3GtWtuXp4eiLgLIbAwk5DEUWNb6o7q","H4GdDDepCYi52gN90fCR8CZX74+I/Q==","tPfxTkGU0+SbbX5KtrDRbUWDeZeFFg==","I2oTmqWMZg8NrIaP89hPf53ud+53VfCNSvt4dCRRw6lAei2KkpxeHzm84p+WyHdvpd5a3klljb15y0BEDmGomSNKcLqDrFovN4ynr5L4ZV/0zlHOUHXJrW/bUlRKcaCJJVouqu28Pj9BnMO/7egQT8W+Or4gBbTdC6tnJA==","InhS98H1+UwKksniIG8=","Ak77tClpxJ/Ni1MKq6/TkpfHPGKj7Q==","lIuJ3Bh74fKc8ttJbZHn//5wQVU=","d+ZVawtMsbInbzqd0olFFDSxuZCQxQ==","3w1rqmyJ3toGfY7xDO8uVtyMCPy2dfBSZqjadf6Lvp8aHpq7k54ny7FuhuER3ztmyrxWzORF9WJ/mM1F9rvsrw8ui4uRrjD77F6/0SHPC3airA==","cE2+ld3jUmxmSZmxT3KrgueUJheetKiX6MA=","hZmkjUEIna1wjGDZumBS737tLFSCig==","0fQ89C5LspMI4S1uJ1fdr0VwUoDUkhARY7bjlc/O","WbXsbsKel4g4C5ewu5MMxNxjtepl6h1R8Ik89814x11FpfF+347JmCEbq4Cpoxr03FOn2nbaF2H2uTHHwEg=","/d14fPDz9fFFSJSO4P5gcxdUv6pid4mFkJEQHLK5nJiOzW1s7ePx4VVYh77kznZD6WQ=","KmqUS16zM2y2nJ6WaBWosk6REsLXZWjoUugEXw==","dqv1jtXbJX718R7v61Uojcv773ShUQGpmXqUiiOc","lJJI4qVvtEgiroRzp4GxlUkQ17XBlHzBvWjL5w==","KorrCUuuf40uxoBhH+wF7L9TK4sd+Z92r19Gp4t4aYh0mv4ZEL49nTT2pFE33D3cw2Nauz3Jp0aabzeXpUhNuEuq3SkujlitCuagQSLMK8zTc1irMNmiVop/dIf4WFyoT7rTOWueXL14lp8x","HvNuStSQUuBHcfFWKaxWcdiHuZNyNQ==","iW+OnRSJyxSssS6QD8W2ZCrr1enDUEiG","kH3p8HvwWVe0j2L9knLFUx2rtXSBhNeeah3luuSZ","u0pmsKNtRYNcl8IWf7M=","A48S2Ix/KO4e7kRV443T+pp3IFDppop7DYktncoY","geGtbvNXXK/VcN2Aa5I=","twobrxySoscxYgvtmeuxUkyInfgmeXFe+KRMeXKPKpvFGkK/KqKs92NSOt2u24JidLjmyFdJRG7OlGFJRb9Sqw=="],k=[71,190,98,147,134,4,160,130,214,112,254,255,71,158,239,97],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
(() => {
 'use strict';const $=id=>document.getElementById(id),el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
 let state={scripts:[]},filter='all',editing=null,dirty=false,timer;
 const template='// ==UserScript==\n// @name         My userscript\n// @namespace    blackmamer-personal\n// @version      1.0\n// @description  My browser, my workflow.\n// @match        https://example.com/*\n// @grant        none\n// ==/UserScript==\n\n(function () {\n  \'use strict\';\n\n  // Your code here.\n})();\n';
 async function api(action,data={}){const r=await chrome.runtime.sendMessage({bm:{action,...data}});if(!r?.ok)throw Error(r?.error||'Engine tidak merespons.');return r.result;}
 function toast(text){$('toast').textContent=text;$('toast').hidden=false;clearTimeout(timer);timer=setTimeout(()=>$('toast').hidden=true,5500);}
 function show(name){for(const id of [(__BMS_e0b46f8999(0)),'editor',(__BMS_e0b46f8999(1)),(__BMS_e0b46f8999(2))])$(id+'-view').hidden=id!==name;$('breadcrumb').textContent={library:'Script library',editor:'Personal editor',install:'Install product',settings:(__BMS_e0b46f8999(3))}[name];}
 async function refresh(){try{state=await api('state');$((__BMS_e0b46f8999(4))).textContent=state.version;$((__BMS_e0b46f8999(5))).setAttribute((__BMS_e0b46f8999(6)),String(state.enabled));$('engine-label').textContent=state.enabled?'Engine active':'Engine paused';$('permission-banner').hidden=state.scriptsAllowed;$('nav-count').textContent=state.scripts.length;$('total-count').replaceChildren(document.createTextNode(state.scripts.length+' '),el('em','scripts'));$((__BMS_e0b46f8999(7))).replaceChildren(document.createTextNode(state.scripts.filter(s=>s.enabled).length+' '),el('em',(__BMS_e0b46f8999(8))));$('paid-count').replaceChildren(document.createTextNode(state.scripts.filter(s=>s.paid).length+' '),el('em','products'));render();}catch(e){toast(e.message);}}
 function selectFilter(value){filter=value;show('library');document.querySelectorAll((__BMS_e0b46f8999(9))).forEach(b=>b.classList.toggle('active',b.dataset.view===value));document.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter===value));render();}
 const licenseClock = new Intl.DateTimeFormat('id-ID', {
   day: 'numeric', month: 'long', year: 'numeric',
   hour: (__BMS_e0b46f8999(10)), minute: (__BMS_e0b46f8999(10)), timeZoneName: 'short'
 });

 function updateLicenseLabel(label, license, now = Date.now()) {
   const status = license?.status === 'active' ? 'Lisensi aktif' : (__BMS_e0b46f8999(11));
   if (license?.expiresAt === null) {
     label.textContent = status + ' · Seumur hidup';
     return;
   }
   const end = Date.parse(license?.expiresAt);
   if (!Number.isFinite(end)) {
     label.textContent = status + (__BMS_e0b46f8999(12));
     return;
   }
   const expired = end <= now;
   label.classList.toggle((__BMS_e0b46f8999(13)), expired);
   const prefix = expired ? 'Lisensi berakhir' : status + ' · Berlaku sampai';
   label.textContent = prefix + ' ' + licenseClock.format(end);
 }

 function updateVisibleLicenses() {
   if (document.hidden) return;
   const licenses = new Map(state.scripts.filter(s => s.paid).map(s => [s.id, s.license]));
   for (const label of document.querySelectorAll((__BMS_e0b46f8999(14)))) {
     updateLicenseLabel(label, licenses.get(label.dataset.licenseId));
   }
 }

 setInterval(updateVisibleLicenses, 15000);
 chrome.storage.onChanged.addListener((changes, area) => {
   if (area === 'local' && changes.bmPurchases && !document.hidden) refresh();
 });
 document.addEventListener('visibilitychange', () => {
   if (!document.hidden) refresh();
 });
 function render(){const term=$('search').value.toLowerCase(),items=state.scripts.filter(s=>(filter==='all'||(filter==='paid')===s.paid)&&(s.name+' '+s.description).toLowerCase().includes(term));$('script-list').replaceChildren();for(const s of items){
  const row=el((__BMS_e0b46f8999(15)),undefined,'script-row'+(s.paid?' paid':'')),icon=el('div',s.paid?'◇':'⌘','script-icon'),info=el('div',undefined,'script-info'),title=el('h3',s.name),badge=el('span',s.paid?(__BMS_e0b46f8999(16)):'PERSONAL','badge');title.append(badge);
  info.append(title, el('p', 'v' + s.version + (s.paid ? '' : ' · ' + (s.description || (__BMS_e0b46f8999(17))))));
  if (s.paid) {
    const label = el('p', undefined, 'license-expiry');
    label.dataset.licenseId = s.id;
    updateLicenseLabel(label, s.license);
    info.append(label);
  }
  const actions=el('div',undefined,'script-actions'),toggle=el('button',undefined,'switch');toggle.setAttribute('role','switch');toggle.setAttribute((__BMS_e0b46f8999(18)),(__BMS_e0b46f8999(19))+s.name);toggle.setAttribute('aria-checked',String(s.enabled));toggle.onclick=async()=>{toggle.disabled=true;try{await api('toggle',{id:s.id,enabled:!s.enabled});await refresh();}catch(e){toast(e.message);}finally{toggle.disabled=false;}};actions.append(toggle);
  if(!s.paid){const edit=el('button','Edit');edit.onclick=()=>openEditor(s.id);actions.append(edit);const exp=el('button','↓');exp.title='Export userscript';exp.onclick=async()=>{try{const r=await api('source',{id:s.id});download(r.source,s.name.replace(/[^\w.-]/g,'_')+'.user.js','text/javascript');}catch(e){toast(e.message);}};actions.append(exp);}
  const remove=el('button','×');remove.title='Hapus '+s.name;remove.onclick=async()=>{if(!confirm('Hapus '+s.name+(__BMS_e0b46f8999(20))))return;try{await api('remove',{id:s.id});await refresh();}catch(e){toast(e.message);}};actions.append(remove);row.append(icon,info,actions);$('script-list').append(row);
 }if(!items.length){const box=el('div',undefined,'empty');box.append(el('div','⌘','empty-symbol'),el('h3',term?'Tidak ada hasil.':(__BMS_e0b46f8999(21))),el('p',term?(__BMS_e0b46f8999(22)):(__BMS_e0b46f8999(23))));const b=el('button',(__BMS_e0b46f8999(24)),(__BMS_e0b46f8999(25)));b.onclick=()=>openEditor();box.append(b);$('script-list').append(box);} $('list-summary').textContent=items.length+' dari '+state.scripts.length+(__BMS_e0b46f8999(26));}
 function download(data,name,type){const url=URL.createObjectURL(new Blob([data],{type})),a=el('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 async function openEditor(id,source){try{editing=id||null;$('code').value=source??(id?(await api('source',{id})).source:template);$('editor-title').textContent=id?'Edit userscript.':(__BMS_e0b46f8999(27));dirty=false;lines();show('editor');$('code').focus();}catch(e){toast(e.message);}}
 function lines(){const count=$('code').value.split('\n').length;$('line-numbers').textContent=Array.from({length:count},(_,i)=>i+1).join('\n');$((__BMS_e0b46f8999(28))).textContent=count+' LINES · UTF-8'+(dirty?' · UNSAVED':'');}
 async function save(){const b=$((__BMS_e0b46f8999(29)));b.disabled=true;try{const r=await api('save',{id:editing||undefined,source:$('code').value});editing=r.id;dirty=false;lines();toast((__BMS_e0b46f8999(30)));await refresh();}catch(e){toast(e.message);}finally{b.disabled=false;}}
 $('code').addEventListener('input',()=>{dirty=true;lines();});$('code').addEventListener('scroll',()=>{$('line-numbers').scrollTop=$('code').scrollTop;});$('code').addEventListener((__BMS_e0b46f8999(31)),e=>{if(e.key==='Tab'){e.preventDefault();const t=e.target;t.setRangeText('  ',t.selectionStart,t.selectionEnd,'end');dirty=true;lines();}});
 document.addEventListener((__BMS_e0b46f8999(31)),e=>{if((e.ctrlKey||e.metaKey)&&e.key==='s'&&!$((__BMS_e0b46f8999(32))).hidden){e.preventDefault();save();}});window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
 $((__BMS_e0b46f8999(29))).onclick=save;$((__BMS_e0b46f8999(33))).onclick=()=>openEditor();$((__BMS_e0b46f8999(34))).onclick=()=>{if(dirty&&!confirm('Tinggalkan perubahan yang belum disimpan?'))return;dirty=false;show((__BMS_e0b46f8999(0)));};
 for(const b of document.querySelectorAll('[data-view],[data-filter]'))b.onclick=()=>{if(dirty&&!confirm((__BMS_e0b46f8999(35))))return;dirty=false;selectFilter(b.dataset.view||b.dataset.filter);};
 $('search').oninput=render;$((__BMS_e0b46f8999(36))).onclick=()=>show((__BMS_e0b46f8999(2)));$((__BMS_e0b46f8999(5))).onclick=async()=>{try{await api('enabled',{enabled:!state.enabled});await refresh();}catch(e){toast(e.message);}};
 $('extension-settings').onclick=()=>chrome.tabs.create({url:'chrome://extensions/?id='+chrome.runtime.id});
 $('import-script').onclick=()=>$('import-file').click();$((__BMS_e0b46f8999(37))).onchange=async e=>{const f=e.target.files[0];if(f){if(f.size>1048576)return toast('File maksimal 1 MB.');await openEditor(null,await f.text());}e.target.value='';};
 $((__BMS_e0b46f8999(38))).onclick=async()=>{try{download(JSON.stringify((await api('export')).backup,null,2),(__BMS_e0b46f8999(39)),'application/json');toast((__BMS_e0b46f8999(40)));}catch(e){toast(e.message);}};
 const pending=new URLSearchParams(location.search).get((__BMS_e0b46f8999(1)));
 $('cancel-install').onclick=()=>{history.replaceState(null,'',(__BMS_e0b46f8999(41)));show((__BMS_e0b46f8999(0)));};
 $('confirm-install').onclick=async()=>{const b=$((__BMS_e0b46f8999(42)));b.disabled=true;try{const r=await api('claim',{id:pending});$((__BMS_e0b46f8999(43))).textContent=r.name+(__BMS_e0b46f8999(44));b.textContent=(__BMS_e0b46f8999(45));await refresh();}catch(e){$('install-result').textContent=e.message;b.disabled=false;}};
 refresh();if(pending){show((__BMS_e0b46f8999(1)));api('pending',{id:pending}).then(({link})=>{$((__BMS_e0b46f8999(46))).textContent=link.name;$((__BMS_e0b46f8999(47))).textContent='Version '+link.version;for(const [label,value] of [['Link berakhir',new Date(link.expiresAt).toLocaleString('id-ID')],[(__BMS_e0b46f8999(48)),link.licenseExpiresAt?new Date(link.licenseExpiresAt).toLocaleDateString('id-ID'):'Lifetime']])$((__BMS_e0b46f8999(49))).append(el('dt',label),el('dd',value));$('install-scopes').textContent='SITUS YANG DIAKSES\n'+link.matches.join('\n');$('confirm-install').disabled=!['ready',(__BMS_e0b46f8999(50))].includes(link.status);if($('confirm-install').disabled)$((__BMS_e0b46f8999(43))).textContent=(__BMS_e0b46f8999(51));}).catch(e=>{$('install-name').textContent='Pemasangan tidak tersedia';$('install-result').textContent=e.message;});}
})();
