/* BlackMamer presentation script. Does not implement or replace the engine. */
(() => {
  'use strict';
  const root = document.documentElement;
  const view = root.dataset.bmView || 'dashboard';
  const THEMES = [
    ['aqua', 'Cyan / BlackMamer'],
    ['gold', 'Gold / Premium'],
    ['ice', 'Ice / Blue'],
    ['mono', 'Graphite / Silver']
  ];
  let selected = 'mono';
  selected = 'mono';
  if (!THEMES.some(([id]) => id === selected)) selected = 'aqua';
  root.dataset.bmTheme = selected;

  const img = (className) => {
    const element = document.createElement('img');
    element.className = className;
    element.src = chrome.runtime.getURL('images/icon128.png');
    element.alt = 'BlackMamer logo';
    return element;
  };
  function mark() {
    if (view !== 'popup') {
      const nativeHead = document.querySelector('.head_container');
      if (nativeHead && !nativeHead.querySelector('.bm-headmark')) {
        const element = document.createElement('a');
        element.className = 'bm-headmark';
        element.href = chrome.runtime.getURL('options.html');
        element.setAttribute('aria-label', 'BlackMamer Dashboard');
        element.append(img('bm-mark-logo'));
        const label = document.createElement('span');
        const title = document.createElement('strong'); title.textContent = 'BLACKMAMER';
        const tiny = document.createElement('small'); tiny.textContent = 'USERSCRIPT STUDIO';
        label.append(title, tiny);
        const version = document.createElement('span');
        version.className = 'bm-version'; version.textContent = 'ENGINE 5.5.1';
        element.append(label, version);
        nativeHead.append(element);
      }
    } else if (view === 'popup') {
      if (!document.querySelector('.bm-popup-head') && document.body) {
        const header = document.createElement('div'); header.className = 'bm-popup-head';
        header.append(img('bm-popup-logo'));
        const label = document.createElement('div');
        const title = document.createElement('div');title.className='bm-brandname'; title.textContent='BlackMamer';
        const sub = document.createElement('div');sub.className='bm-subtitle';sub.textContent='USERSCRIPT MANAGER';
        label.append(title,sub);header.append(label);
        const status = document.createElement('div');status.className='bm-status';status.title='Extension page';
        header.append(status);
        document.body.prepend(header);
      }
    }
  }
  function chooser() {
    if (document.querySelector('.bm-chooser') || !document.body) return;
    const holder = document.createElement('div');holder.className='bm-chooser';
    const trigger=document.createElement('button');trigger.type='button';
    trigger.textContent='◈  Theme';trigger.setAttribute('aria-label','Choose BlackMamer color theme');
    trigger.setAttribute('aria-expanded','false');
    const menu=document.createElement('div');menu.className='bm-menu'; menu.hidden=true;
    const title=document.createElement('div'); title.className='bm-menu-title';title.textContent='APPEARANCE';menu.append(title);
    const buttons=[];
    for (const [id,name] of THEMES) {
      const option=document.createElement('button');option.type='button';option.textContent=name;
      option.setAttribute('aria-pressed',String(selected===id));
      option.addEventListener('click',()=>{
        selected=id;root.dataset.bmTheme=id;
        try {localStorage.setItem('bm-v2-theme',id);} catch (_) {}
        buttons.forEach(([key,element])=>element.setAttribute('aria-pressed',String(key===id)));
        menu.hidden=true;trigger.setAttribute('aria-expanded','false');
      });
      buttons.push([id,option]);menu.append(option);
    }
    trigger.addEventListener('click',()=>{
      menu.hidden=!menu.hidden;trigger.setAttribute('aria-expanded',String(!menu.hidden));
    });
    document.addEventListener('click',(event)=>{
      if (!holder.contains(event.target)) {menu.hidden=true;trigger.setAttribute('aria-expanded','false');}
    });
    document.addEventListener('keydown',(event)=>{
      if (event.key==='Escape') {menu.hidden=true;trigger.setAttribute('aria-expanded','false');}
    });
    holder.append(trigger,menu); document.body.append(holder);
  }
  let updateScheduled=false;
  const doUpdate=()=>{
    updateScheduled=false;
    if (!document.body) return;
    mark();
    if (document.title && document.title.includes('BlackMamer')) document.title=document.title.replaceAll('BlackMamer','BlackMamer');
  };
  const requestUpdate=()=>{
    if (updateScheduled) return;
    updateScheduled=true;
    requestAnimationFrame(doUpdate);
  };
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', requestUpdate,{once:true});
  else requestUpdate();
  const observer=new MutationObserver(requestUpdate);
  observer.observe(document.documentElement,{childList:true,subtree:true});
})();
