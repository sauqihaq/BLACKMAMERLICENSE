
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_92088290a9=(()=>{const d=["+58xUI3+ehKqyKzDB2bwgumN","H4X0hOz3XGugRaKXzlVd9zCJ75YgW/f3vR2lwXDIwW86lQ==","3PB0gHydTVKW+LMUa8quwQdoe4xxj6f+","QcbEYeiHJYbj8X5tE0dTldpbbPmZi0aU","15MEUb/zx4WamhRXt/tYGYXFh8w=","jhCczhPF4WQBgMyD3vI5YJxInJjlWH/8","CGnrQweRHFeo9VeHSZg8Wfb1rRsGx8fKdm0LixSK","W1AN/6kV8cmTwB5nN439jDv/lmM=","r4fR9g9sekSxlG5Uy/i+iOKVaFrL8CMc/MI=","soNtnO1VFPl7F3nLs84UaaWPOo4y+Ztld08=","SGI3hm6B//BXbqxGWJpOWvb6CooEkw==","EFC19BmEmZmVVin02Bjaxq3N","js/JwmNlx4OWguz9dWFdS5WZQ1/0/Q==","UkJelm9Ws/aQhkeXh1g/9lkaU8A=","1f/WFf3KPcGBaOeMu48W/pZkd0ynnKRcJ+DvkOSNnUIU6G4E4dot0Y54/Zz5n2TunnRuXLGMskwf0A==","dfHKbaFHtJU3W9X5JIvylOhdXvGwH7LDwtY=","bZutVEP67xY9xD3Pg2o=","qoF7gDDz0W89STWbX1ml+9SNGZLEX3jzAQE=","A/X2h/GYlVkP9TQb+8c0yplt74s=","/8N2ZkWCnY0R/PBigkqInlFe+/4Bjt6P","RJeLVWv3QIkVlsVbMvfCHRXBFsi7bw==","FxQEytfBmGl/j7mOq/k="],k=[159,81,252,17,204,198,96,133,133,245,104,65,146,83,240,129],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
/* BlackMamer presentation script. Does not implement or replace the engine. */
(() => {
  'use strict';
  const root = document.documentElement;
  const view = root.dataset.bmView || (__BMS_92088290a9(0));
  const THEMES = [
    ['aqua', 'Cyan / BlackMamer'],
    ['gold', 'Gold / Premium'],
    ['ice', 'Ice / Blue'],
    ['mono', (__BMS_92088290a9(1))]
  ];
  let selected = 'mono';
  selected = 'mono';
  if (!THEMES.some(([id]) => id === selected)) selected = 'aqua';
  root.dataset.bmTheme = selected;

  const img = (className) => {
    const element = document.createElement('img');
    element.className = className;
    element.src = chrome.runtime.getURL('images/icon128.png');
    element.alt = 'BlackMamer logo';
    return element;
  };
  function mark() {
    if (view !== 'popup') {
      const nativeHead = document.querySelector('.head_container');
      if (nativeHead && !nativeHead.querySelector((__BMS_92088290a9(2)))) {
        const element = document.createElement('a');
        element.className = 'bm-headmark';
        element.href = chrome.runtime.getURL((__BMS_92088290a9(3)));
        element.setAttribute((__BMS_92088290a9(4)), 'BlackMamer Dashboard');
        element.append(img((__BMS_92088290a9(5))));
        const label = document.createElement('span');
        const title = document.createElement('strong'); title.textContent = 'BLACKMAMER';
        const tiny = document.createElement('small'); tiny.textContent = (__BMS_92088290a9(6));
        label.append(title, tiny);
        const version = document.createElement('span');
        version.className = (__BMS_92088290a9(7)); version.textContent = 'ENGINE 5.5.1';
        element.append(label, version);
        nativeHead.append(element);
      }
    } else if (view === 'popup') {
      if (!document.querySelector('.bm-popup-head') && document.body) {
        const header = document.createElement('div'); header.className = (__BMS_92088290a9(8));
        header.append(img((__BMS_92088290a9(9))));
        const label = document.createElement('div');
        const title = document.createElement('div');title.className='bm-brandname'; title.textContent='BlackMamer';
        const sub = document.createElement('div');sub.className=(__BMS_92088290a9(10));sub.textContent="BMscript MANAGER";
        label.append(title,sub);header.append(label);
        const status = document.createElement('div');status.className=(__BMS_92088290a9(11));status.title='Extension page';
        header.append(status);
        document.body.prepend(header);
      }
    }
  }
  function chooser() {
    if (document.querySelector((__BMS_92088290a9(12))) || !document.body) return;
    const holder = document.createElement('div');holder.className=(__BMS_92088290a9(13));
    const trigger=document.createElement('button');trigger.type='button';
    trigger.textContent='◈  Theme';trigger.setAttribute((__BMS_92088290a9(4)),(__BMS_92088290a9(14)));
    trigger.setAttribute((__BMS_92088290a9(15)),'false');
    const menu=document.createElement('div');menu.className=(__BMS_92088290a9(16)); menu.hidden=true;
    const title=document.createElement('div'); title.className=(__BMS_92088290a9(17));title.textContent=(__BMS_92088290a9(18));menu.append(title);
    const buttons=[];
    for (const [id,name] of THEMES) {
      const option=document.createElement('button');option.type='button';option.textContent=name;
      option.setAttribute((__BMS_92088290a9(19)),String(selected===id));
      option.addEventListener('click',()=>{
        selected=id;root.dataset.bmTheme=id;
        try {localStorage.setItem((__BMS_92088290a9(20)),id);} catch (_) {}
        buttons.forEach(([key,element])=>element.setAttribute('aria-pressed',String(key===id)));
        menu.hidden=true;trigger.setAttribute((__BMS_92088290a9(15)),'false');
      });
      buttons.push([id,option]);menu.append(option);
    }
    trigger.addEventListener('click',()=>{
      menu.hidden=!menu.hidden;trigger.setAttribute((__BMS_92088290a9(15)),String(!menu.hidden));
    });
    document.addEventListener('click',(event)=>{
      if (!holder.contains(event.target)) {menu.hidden=true;trigger.setAttribute((__BMS_92088290a9(15)),'false');}
    });
    document.addEventListener((__BMS_92088290a9(21)),(event)=>{
      if (event.key==='Escape') {menu.hidden=true;trigger.setAttribute('aria-expanded','false');}
    });
    holder.append(trigger,menu); document.body.append(holder);
  }
  let updateScheduled=false;
  const doUpdate=()=>{
    updateScheduled=false;
    if (!document.body) return;
    mark();
    if (document.title && document.title.includes('BlackMamer')) document.title=document.title.replaceAll('BlackMamer','BlackMamer');
  };
  const requestUpdate=()=>{
    if (updateScheduled) return;
    updateScheduled=true;
    requestAnimationFrame(doUpdate);
  };
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', requestUpdate,{once:true});
  else requestUpdate();
  const observer=new MutationObserver(requestUpdate);
  observer.observe(document.documentElement,{childList:true,subtree:true});
})();
