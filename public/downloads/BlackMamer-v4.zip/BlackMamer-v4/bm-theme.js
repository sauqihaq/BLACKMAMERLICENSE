
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_cc3b915f42=(()=>{const d=["ZQH0lXQHlPyA4g9gw6IsXglt","8VneZE96mIF8HUKUQ2235mi17AgYnuYOgfM767VrOKvUSQ==","GOGovJwDwJd8Aev6aOCWYhasR1Dvb2Jz","zGUupbBbJmbbfG+HLx/Nlh9jleh3t2wK","1JA8aa7i+7kEBNGSTgK296/vJG8=","sv4C5NZmGKDvXOZjfX/9ikAQfJtoYJXt","8YMFGy2Sv29s5Iu7qQaxnBwM9fUF7f9pZ6k3V4pq","+JXJBnX7EeMeY/Sjb1H+bANyh4k=","T2dce+WGIhyyl1Zs2umCtHwLrZ8yCc3y1ug=","6r9uAtWQBQBH+efhdm3trUtTEG6RdF+Pqxc=","WaYLWvBhOn2uhEIecpntYjLr1rbkDQ==","1WhM5fe4swc2k+0NBPY67CBu","pOVqYaehG192YmFwn4sFE5aae2fl7A==","jhq+leJuWefIukQJv50uD2X0zeo=","PwaO+/7gBWKQrNtQJW/Tc2+OmRSNnwdk4/EzrAQTEIf+ETbq4vAVcp+8wUBnf6FjZ56ABJuPEXTbwQ==","TXzbh50fKpbyYyzoyrfYCkuYmghs8VLpT3U=","8wVokboDAfgX7p5sR64=","RF1RYJN+FYXhEdWY0mFP6oyxGgz8mmkKPe8=","x+QquxEGGJzlDGz1+O0MaYip01c=","cmCcoh1enm0pceGIvhIWnZRmAu/vsvQR","R5SzbXrmfLWLCACeyw4s8z/rtWt/qw==","K/qa4BJiYa2RU5NuCHQ="],k=[1,148,5,255,230,101,164,89,101,120,130,25,145,107,225,189],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
/* BlackMamer presentation script. Does not implement or replace the engine. */
(() => {
  'use strict';
  const root = document.documentElement;
  const view = root.dataset.bmView || (__BMS_cc3b915f42(0));
  const THEMES = [
    ['aqua', 'Cyan / BlackMamer'],
    ['gold', 'Gold / Premium'],
    ['ice', 'Ice / Blue'],
    ['mono', (__BMS_cc3b915f42(1))]
  ];
  let selected = 'mono';
  selected = 'mono';
  if (!THEMES.some(([id]) => id === selected)) selected = 'aqua';
  root.dataset.bmTheme = selected;

  const img = (className) => {
    const element = document.createElement('img');
    element.className = className;
    element.src = chrome.runtime.getURL('images/icon128.png');
    element.alt = 'BlackMamer logo';
    return element;
  };
  function mark() {
    if (view !== 'popup') {
      const nativeHead = document.querySelector('.head_container');
      if (nativeHead && !nativeHead.querySelector((__BMS_cc3b915f42(2)))) {
        const element = document.createElement('a');
        element.className = 'bm-headmark';
        element.href = chrome.runtime.getURL((__BMS_cc3b915f42(3)));
        element.setAttribute((__BMS_cc3b915f42(4)), 'BlackMamer Dashboard');
        element.append(img((__BMS_cc3b915f42(5))));
        const label = document.createElement('span');
        const title = document.createElement('strong'); title.textContent = 'BLACKMAMER';
        const tiny = document.createElement('small'); tiny.textContent = (__BMS_cc3b915f42(6));
        label.append(title, tiny);
        const version = document.createElement('span');
        version.className = (__BMS_cc3b915f42(7)); version.textContent = 'ENGINE 5.5.1';
        element.append(label, version);
        nativeHead.append(element);
      }
    } else if (view === 'popup') {
      if (!document.querySelector('.bm-popup-head') && document.body) {
        const header = document.createElement('div'); header.className = (__BMS_cc3b915f42(8));
        header.append(img((__BMS_cc3b915f42(9))));
        const label = document.createElement('div');
        const title = document.createElement('div');title.className='bm-brandname'; title.textContent='BlackMamer';
        const sub = document.createElement('div');sub.className=(__BMS_cc3b915f42(10));sub.textContent="BMscript MANAGER";
        label.append(title,sub);header.append(label);
        const status = document.createElement('div');status.className=(__BMS_cc3b915f42(11));status.title='Extension page';
        header.append(status);
        document.body.prepend(header);
      }
    }
  }
  function chooser() {
    if (document.querySelector((__BMS_cc3b915f42(12))) || !document.body) return;
    const holder = document.createElement('div');holder.className=(__BMS_cc3b915f42(13));
    const trigger=document.createElement('button');trigger.type='button';
    trigger.textContent='◈  Theme';trigger.setAttribute((__BMS_cc3b915f42(4)),(__BMS_cc3b915f42(14)));
    trigger.setAttribute((__BMS_cc3b915f42(15)),'false');
    const menu=document.createElement('div');menu.className=(__BMS_cc3b915f42(16)); menu.hidden=true;
    const title=document.createElement('div'); title.className=(__BMS_cc3b915f42(17));title.textContent=(__BMS_cc3b915f42(18));menu.append(title);
    const buttons=[];
    for (const [id,name] of THEMES) {
      const option=document.createElement('button');option.type='button';option.textContent=name;
      option.setAttribute((__BMS_cc3b915f42(19)),String(selected===id));
      option.addEventListener('click',()=>{
        selected=id;root.dataset.bmTheme=id;
        try {localStorage.setItem((__BMS_cc3b915f42(20)),id);} catch (_) {}
        buttons.forEach(([key,element])=>element.setAttribute('aria-pressed',String(key===id)));
        menu.hidden=true;trigger.setAttribute((__BMS_cc3b915f42(15)),'false');
      });
      buttons.push([id,option]);menu.append(option);
    }
    trigger.addEventListener('click',()=>{
      menu.hidden=!menu.hidden;trigger.setAttribute((__BMS_cc3b915f42(15)),String(!menu.hidden));
    });
    document.addEventListener('click',(event)=>{
      if (!holder.contains(event.target)) {menu.hidden=true;trigger.setAttribute((__BMS_cc3b915f42(15)),'false');}
    });
    document.addEventListener((__BMS_cc3b915f42(21)),(event)=>{
      if (event.key==='Escape') {menu.hidden=true;trigger.setAttribute('aria-expanded','false');}
    });
    holder.append(trigger,menu); document.body.append(holder);
  }
  let updateScheduled=false;
  const doUpdate=()=>{
    updateScheduled=false;
    if (!document.body) return;
    mark();
    if (document.title && document.title.includes('BlackMamer')) document.title=document.title.replaceAll('BlackMamer','BlackMamer');
  };
  const requestUpdate=()=>{
    if (updateScheduled) return;
    updateScheduled=true;
    requestAnimationFrame(doUpdate);
  };
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', requestUpdate,{once:true});
  else requestUpdate();
  const observer=new MutationObserver(requestUpdate);
  observer.observe(document.documentElement,{childList:true,subtree:true});
})();
