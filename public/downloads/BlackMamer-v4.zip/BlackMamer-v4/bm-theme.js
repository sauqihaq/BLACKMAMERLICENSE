
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_09d0e238a5=(()=>{const d=["heHAoRhrDGQJa7TbwqM6SPyY","aU9XkfQ0mehqvbfYDf3eOMgOoOiIqjhiOmvbYoHQVKpMXw==","GT++B2njjqMVbUtiJGkG2cit/EYPmlY9","gt5HpBBNapNLMrHulL8t2ivz+TbvDOXq","mNys+XA8QALk5OWmIm4ubyZmn9Q=","CWbibeLddKF3Sm+WxjH841awidcm8Pwz","iuqDu5LeNf9MOrcAfubCqAVgUm09ZGnSqaiQQWGfLCbg+g==","Q6HIamNj4WpA2I2iyEeymYg8W+BqtQ==","jZIsNeTvoLzC2/X8IzcAD+HrpasbZXlqemHF0bK1X16Ngj0l","SgQi4kWk2GznYRZoQ9aErI1F","y6e/TFCUUDPU7dC+4NVQ8jQ1yQ0G7Q==","4fggO28DKueRp+JhCW7JZXjVtak=","y0mT2uugdEmIlyI+9OKvsw==","ubpO2e7+PDlzAQLpYKnBY9dsPmN808Kr60DMgHAnBPn4qnbJku5MKRwRePlCudNzv3xHcwrD1LvTUA==","dGo0Y7Rpm9kQrWBGnZrVPQ7nDrQD07L0yy8=","3jIa7mK/xtqO80s2Xww=","EOVDpZJvlWDWZzvXQa+9RHuc3DsU5Ua2","1UvQlXwwHez9sTnUh/E=","xToAANXmcKimYNNtlGS/0nCoX0E=","Mdvoo7VI15j9PyHhELI="],k=[225,160,105,103,111,222,165,79,144,54,235,185,221,251,63,6],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
/* BlackMamer presentation script. Does not implement or replace the engine. */
(() => {
  'use strict';
  const root = document.documentElement;
  const view = root.dataset.bmView || (__BMS_09d0e238a5(0));
  const THEMES = [
    ['aqua', 'Cyan / BlackMamer'],
    ['gold', 'Gold / Premium'],
    ['ice', 'Ice / Blue'],
    ['mono', (__BMS_09d0e238a5(1))]
  ];
  let selected = 'mono';
  selected = 'mono';
  if (!THEMES.some(([id]) => id === selected)) selected = 'aqua';
  root.dataset.bmTheme = selected;

  const img = (className) => {
    const element = document.createElement('img');
    element.className = className;
    element.src = chrome.runtime.getURL('images/icon128.png');
    element.alt = 'BlackMamer logo';
    return element;
  };
  function mark() {
    if (view !== 'popup') {
      const nativeHead = document.querySelector('.head_container');
      if (nativeHead && !nativeHead.querySelector((__BMS_09d0e238a5(2)))) {
        const element = document.createElement('a');
        element.className = 'bm-headmark';
        element.href = chrome.runtime.getURL((__BMS_09d0e238a5(3)));
        element.setAttribute((__BMS_09d0e238a5(4)), 'BlackMamer Dashboard');
        element.append(img((__BMS_09d0e238a5(5))));
        const label = document.createElement('span');
        const title = document.createElement('strong'); title.textContent = 'BLACKMAMER';
        const tiny = document.createElement('small'); tiny.textContent = (__BMS_09d0e238a5(6));
        label.append(title, tiny);
        const version = document.createElement('span');
        version.className = 'bm-version'; version.textContent = 'ENGINE 5.5.1';
        element.append(label, version);
        nativeHead.append(element);
      }
    } else if (view === 'popup') {
      if (!document.querySelector('.bm-popup-head') && document.body) {
        const header = document.createElement('div'); header.className = 'bm-popup-head';
        header.append(img('bm-popup-logo'));
        const label = document.createElement('div');
        const title = document.createElement('div');title.className='bm-brandname'; title.textContent='BlackMamer';
        const sub = document.createElement('div');sub.className=(__BMS_09d0e238a5(7));sub.textContent=(__BMS_09d0e238a5(8));
        label.append(title,sub);header.append(label);
        const status = document.createElement('div');status.className=(__BMS_09d0e238a5(9));status.title='Extension page';
        header.append(status);
        document.body.prepend(header);
      }
    }
  }
  function chooser() {
    if (document.querySelector((__BMS_09d0e238a5(10))) || !document.body) return;
    const holder = document.createElement('div');holder.className=(__BMS_09d0e238a5(11));
    const trigger=document.createElement('button');trigger.type='button';
    trigger.textContent=(__BMS_09d0e238a5(12));trigger.setAttribute('aria-label',(__BMS_09d0e238a5(13)));
    trigger.setAttribute((__BMS_09d0e238a5(14)),'false');
    const menu=document.createElement('div');menu.className=(__BMS_09d0e238a5(15)); menu.hidden=true;
    const title=document.createElement('div'); title.className='bm-menu-title';title.textContent='APPEARANCE';menu.append(title);
    const buttons=[];
    for (const [id,name] of THEMES) {
      const option=document.createElement('button');option.type='button';option.textContent=name;
      option.setAttribute((__BMS_09d0e238a5(16)),String(selected===id));
      option.addEventListener('click',()=>{
        selected=id;root.dataset.bmTheme=id;
        try {localStorage.setItem('bm-v2-theme',id);} catch (_) {}
        buttons.forEach(([key,element])=>element.setAttribute('aria-pressed',String(key===id)));
        menu.hidden=true;trigger.setAttribute((__BMS_09d0e238a5(14)),'false');
      });
      buttons.push([id,option]);menu.append(option);
    }
    trigger.addEventListener('click',()=>{
      menu.hidden=!menu.hidden;trigger.setAttribute('aria-expanded',String(!menu.hidden));
    });
    document.addEventListener('click',(event)=>{
      if (!holder.contains(event.target)) {menu.hidden=true;trigger.setAttribute((__BMS_09d0e238a5(14)),'false');}
    });
    document.addEventListener((__BMS_09d0e238a5(17)),(event)=>{
      if (event.key==='Escape') {menu.hidden=true;trigger.setAttribute((__BMS_09d0e238a5(14)),'false');}
    });
    holder.append(trigger,menu); document.body.append(holder);
  }
  let updateScheduled=false;
  const doUpdate=()=>{
    updateScheduled=false;
    if (!document.body) return;
    mark();
    if (document.title && document.title.includes((__BMS_09d0e238a5(18)))) document.title=document.title.replaceAll((__BMS_09d0e238a5(18)),(__BMS_09d0e238a5(18)));
  };
  const requestUpdate=()=>{
    if (updateScheduled) return;
    updateScheduled=true;
    requestAnimationFrame(doUpdate);
  };
  if (document.readyState===(__BMS_09d0e238a5(19))) document.addEventListener('DOMContentLoaded', requestUpdate,{once:true});
  else requestUpdate();
  const observer=new MutationObserver(requestUpdate);
  observer.observe(document.documentElement,{childList:true,subtree:true});
})();
