
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_609174aec9=(()=>{const d=["ZAkkQWAToNOL6jdQmP0=","20zpckGs5PlIh2mFpN71KIDtlwDaSi4a9dwM40Nb","GS+t5IILS0MNFWbVfehsUtzzEEXmeaml7vYjjiKO","N1Vr+gFOG3Bfqpv/QYWlh/DQvCZ670YC7UxBHODeyuEVRVnqIF49YHK6","4YGW2nostuFEDAdGSBaS2OLnDF+w8BFAM37qoLz1xZPHkcPKOTyf8UQcGFZfBsvIp/cET6TgHVBUbs+w0OWho6ih/PoEDMPBLywnZg=="],k=[9,64,17,208,238,85,251,76,115,174,250,131,128,216,47,229],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
(() => {
 if(window.top!==window)return;
 let lastOpen=0;
 window.addEventListener((__BMS_609174aec9(0)),async event=>{
  const m=event.data;
  if(event.source!==window||event.origin!==location.origin||m?.channel!==(__BMS_609174aec9(1))||!['ping',(__BMS_609174aec9(2))].includes(m.action)||typeof m.id!=='string'||m.id.length>80)return;
  if(m.action===(__BMS_609174aec9(2))){if(Date.now()-lastOpen<1500)return;lastOpen=Date.now();}
  try{const response=await chrome.runtime.sendMessage({bm:{action:m.action,token:m.action===(__BMS_609174aec9(2))?m.token:undefined}});window.postMessage({channel:(__BMS_609174aec9(3)),id:m.id,...(response.ok?{result:response.result}:{error:response.error})},location.origin);}
  catch{window.postMessage({channel:'BM_EXTENSION_RESPONSE',id:m.id,error:(__BMS_609174aec9(4))},location.origin);}
 });
})();
