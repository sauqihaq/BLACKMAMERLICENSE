(() => {
 if(window.top!==window)return;
 let lastOpen=0;
 window.addEventListener('message',async event=>{
  const m=event.data;
  if(event.source!==window||event.origin!==location.origin||m?.channel!=='BM_SITE_REQUEST'||!['ping','prepare-install'].includes(m.action)||typeof m.id!=='string'||m.id.length>80)return;
  if(m.action==='prepare-install'){if(Date.now()-lastOpen<1500)return;lastOpen=Date.now();}
  try{const response=await chrome.runtime.sendMessage({bm:{action:m.action,token:m.action==='prepare-install'?m.token:undefined}});window.postMessage({channel:'BM_EXTENSION_RESPONSE',id:m.id,...(response.ok?{result:response.result}:{error:response.error})},location.origin);}
  catch{window.postMessage({channel:'BM_EXTENSION_RESPONSE',id:m.id,error:'Ekstensi terputus. Muat ulang halaman.'},location.origin);}
 });
})();
