
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_168795141e=(()=>{const d=["+ZTpjN+sUSIGZ4/oSy4=","KrxkgflSN+e4Xpq5WoDrpFk5q52Eh6KlIS2Rbo7j","yqNdMHGWtY4Tqr8kQWUy6lAgxLV7imRbUejSV6+y","ye11Kdi+J4MBVBfhlVw4uz2OA6qLO8ufVYGSoxAvOWzr/Uc5+a4BkyxE","3b3IhPagYjXZkcqL96ljKW9qtOdjI+GwwI0UXqLrHEr7rZ2UtbBLJdmB1ZvguTo5Knq893cz7aCnnTFOzvt4epSdoqSIgBcVsrHqqw=="],k=[148,141,174,33,99,237,40,188,128,80,228,90,188,134,163,49],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
(() => {
 if(window.top!==window)return;
 let lastOpen=0;
 window.addEventListener((__BMS_168795141e(0)),async event=>{
  const m=event.data;
  if(event.source!==window||event.origin!==location.origin||m?.channel!==(__BMS_168795141e(1))||!['ping',(__BMS_168795141e(2))].includes(m.action)||typeof m.id!=='string'||m.id.length>80)return;
  if(m.action===(__BMS_168795141e(2))){if(Date.now()-lastOpen<1500)return;lastOpen=Date.now();}
  try{const response=await chrome.runtime.sendMessage({bm:{action:m.action,token:m.action===(__BMS_168795141e(2))?m.token:undefined}});window.postMessage({channel:(__BMS_168795141e(3)),id:m.id,...(response.ok?{result:response.result}:{error:response.error})},location.origin);}
  catch{window.postMessage({channel:'BM_EXTENSION_RESPONSE',id:m.id,error:(__BMS_168795141e(4))},location.origin);}
 });
})();
