
/* BLACKMAMERSTUDIO static MV3-safe obfuscation */
const __BMS_f8f9a4c9a4=(()=>{const d=["QC1yF4j79YZCIzleE3Y=","jo4gJ0+Jb02K/zwSgUNBnPhGACRHHJryXokoKhVV","kptvT9cvbhW5/R6A6iHxXGh4u4fCLP+ABkJ29usZ","ElvfcXmMjCXCjy9L6v2BEKZNVJIvRI8m4xrK9CKLnygwS+1hWJyqNe+f","dhYLR86YHUpgKFEQoP7HjSsuAlE7e9OCZivPhQhBvetQBl5XjYg0WmA4TgC37p6dbj4KQS9r35IBO+qVZFHZ2z82YWewuGhqCwhxMA=="],k=[45,22,249,133,39,91,112,142,38,139,78,251,23,69,155,78],c=[];return i=>{if(c[i]!==undefined)return c[i];const b=atob(d[i]),n=b.length>>1,o=new Array(n);for(let j=0;j<n;j++){const m=(((k[(j+i*7)%k.length]<<8)|k[(j+i*3)%k.length])^((j*257+i*73)&65535))&65535;o[j]=String.fromCharCode(((b.charCodeAt(j*2)|b.charCodeAt(j*2+1)<<8)^m)&65535)}return c[i]=o.join('')}})();
(() => {
 if(window.top!==window)return;
 let lastOpen=0;
 window.addEventListener((__BMS_f8f9a4c9a4(0)),async event=>{
  const m=event.data;
  if(event.source!==window||event.origin!==location.origin||m?.channel!==(__BMS_f8f9a4c9a4(1))||!['ping',(__BMS_f8f9a4c9a4(2))].includes(m.action)||typeof m.id!=='string'||m.id.length>80)return;
  if(m.action===(__BMS_f8f9a4c9a4(2))){if(Date.now()-lastOpen<1500)return;lastOpen=Date.now();}
  try{const response=await chrome.runtime.sendMessage({bm:{action:m.action,token:m.action===(__BMS_f8f9a4c9a4(2))?m.token:undefined}});window.postMessage({channel:(__BMS_f8f9a4c9a4(3)),id:m.id,...(response.ok?{result:response.result}:{error:response.error})},location.origin);}
  catch{window.postMessage({channel:'BM_EXTENSION_RESPONSE',id:m.id,error:(__BMS_f8f9a4c9a4(4))},location.origin);}
 });
})();
